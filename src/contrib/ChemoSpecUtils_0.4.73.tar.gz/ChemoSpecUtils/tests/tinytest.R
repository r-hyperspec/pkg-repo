if (require(tinytest, quietly = TRUE)) test_package("ChemoSpecUtils")

