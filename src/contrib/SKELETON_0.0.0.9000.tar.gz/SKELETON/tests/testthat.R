library(hySpc.testthat)
library(SKELETON)

test_check("SKELETON")
