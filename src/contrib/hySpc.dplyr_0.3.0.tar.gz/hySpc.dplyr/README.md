
<!-- badges: start -->
[![CRAN status](https://www.r-pkg.org/badges/version/hySpc.dplyr)](https://cran.r-project.org/package=hySpc.dplyr)
[![R build status](https://github.com/r-hyperspec/hySpc.dplyr/workflows/R-CMD-check/badge.svg)](https://github.com/r-hyperspec/hySpc.dplyr/actions)
[![Codecov test coverage](https://codecov.io/gh/r-hyperspec/hySpc.dplyr/branch/develop/graph/badge.svg)](https://codecov.io/gh/r-hyperspec/hySpc.dplyr?branch=develop)
[![Website (pkgdown)](https://github.com/r-hyperspec/hySpc.dplyr/actions/workflows/pkgdown.yaml/badge.svg)](https://github.com/r-hyperspec/hySpc.dplyr/actions/workflows/pkgdown.yaml)
[![Project Status: WIP – Initial development is in progress, but there has not yet been a stable, usable release suitable for the public.](https://www.repostatus.org/badges/latest/wip.svg)](https://www.repostatus.org/#wip)
<!-- badges: end -->


# R Pacakge **hySpc.dplyr**

Make **hyperSpec** work smoothly with [**dplyr**](https://dplyr.tidyverse.org/) (fortification).
