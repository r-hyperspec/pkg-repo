## ----setup, include = FALSE---------------------------------------------------
library(hyperSpec)
library(hySpc.dplyr)
library(hySpc.chondro)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  results = "hide"
)

## ----filter-extra-data--------------------------------------------------------
flu %>% 
  filter (c > 0.2)

flu %>% 
  filter (c %>% between (0.15, 0.25))

## ----filter spc empty spectra-------------------------------------------------
flu %>%
  filter (!all_wl (is.na (spc)))

## ----filter spc NAs-----------------------------------------------------------
flu %>%
  filter (!any_wl (is.na (spc)))

## ----filter spc between-------------------------------------------------------
flu %>%
  filter (all_wl (between (spc, 0, 500)))

## ----filter spc avg intensity between-----------------------------------------
flu %>% 
  filter (rowMeans (spc) %>% between (0, 500))

## ----slice--------------------------------------------------------------------
chondro %>% 
  slice (1:3)

chondro %>% 
  slice (800 : n())

chondro %>% 
  slice (-10 : -n())

flu %>% 
  slice (1, 3, 5)

## ---- results='show'----------------------------------------------------------
chondro %>% 
  select (clusters, spc)

## ---- results='show'----------------------------------------------------------
flu %>% 
  select (-spc) 

## ---- results='show'----------------------------------------------------------
flu %>% 
  select (-spc) %>%
  as.hyperSpec ()

## ---- results='show'----------------------------------------------------------
chondro %>% 
  rename(region = clusters)

## ---- results='show'----------------------------------------------------------
laser %>%
 mutate (t, filename)
 head # => results in a hyperSpec object
 
laser %>%
  mutate (-spc) # => results in a hyperSpec object

laser %>%
  mutate (spc2 = spc*2) %>%
  mutate (spc2) %>%
  mutate (spc2*2) # => results in a hyperSpec object

## ---- results='show'----------------------------------------------------------
laser %>%
 transmute (t, filename)
 head # => results in a data frame
 
laser %>%
  transmute (-spc) # => results in a hyperSpec object

laser %>%
  transmute (spc2 = spc*2) %>%
  transmute (spc2) %>%
  transmute (spc2*2) # => results in a hyperSpec object

## ---- results='show'----------------------------------------------------------
flu %>%
  setLabels(.wavelength = "f / THz", c = "c / ml")

## ---- results='show'----------------------------------------------------------
sessionInfo()

