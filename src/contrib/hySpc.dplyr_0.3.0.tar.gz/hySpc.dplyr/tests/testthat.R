library(testthat)
library(hySpc.testthat)
library(hySpc.dplyr)

test_check("hySpc.dplyr")
