# C. Beleites
# run all tests attached to objects
unittest("hySpc.dplyr", standalone = FALSE)
