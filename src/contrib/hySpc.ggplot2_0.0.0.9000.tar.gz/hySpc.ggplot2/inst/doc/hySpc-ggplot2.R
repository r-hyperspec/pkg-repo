## ----cleanup-plotting, include = FALSE----------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)
library(ggplot2)
library(hySpc.ggplot2)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporaty options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes = getOption("show_reviewers_notes", TRUE)

## ----bib, echo=FALSE, paged.print=FALSE-----------------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c(
    "hyperSpec",
    "ggplot2",
    "hySpc.ggplot2"
  ),
  file = "resources/hySpc.ggplot2-pkg.bib"
)

## ----packages-------------------------------------------------------------------------------------
library(hyperSpec)
library(ggplot2)
library(hySpc.ggplot2)

theme_set(theme_bw())

set.seed(2020)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra produced by `qplotspc()`{.r}: `flu` data.  "

## ----ggplotspc-01, fig.cap=CAPTION----------------------------------------------------------------
qplotspc(flu) + aes(colour = c)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra with reversed order of x axis values: `paracetamol` data.  "


## ----ggplotspc-02, fig.cap=CAPTION----------------------------------------------------------------
qplotspc(paracetamol, c(2800 ~ max, min ~ 1800)) +
  scale_x_reverse(breaks = seq(0, 3200, 400))

## -------------------------------------------------------------------------------------------------
set.seed(1)
faux_cell <- generate_faux_cell()
faux_cell

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Ten randomly selected spectra from `faux_cell` dataset.  "

## ----ggplotspc-03, fig.cap=CAPTION----------------------------------------------------------------
set.seed(25)
qplotspc(sample(faux_cell), spc.nmax = 10) + aes(colour = region)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Mean spectra of each region in `faux_cell` dataset.  "


## ----ggplotspc-04, fig.cap=CAPTION----------------------------------------------------------------
qplotspc(
  aggregate(faux_cell, faux_cell$region, mean),
  mapping = aes(x = .wavelength, y = spc, colour = region)
) +
  facet_grid(region ~ .)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Mean $\\pm$ standard deviation spectra of each region in `faux_cell` dataset.  "


## ----ggplotspc-05, fig.cap=CAPTION----------------------------------------------------------------
qplotspc(
 aggregate(faux_cell, faux_cell$region, mean_pm_sd),
 mapping = aes(x = .wavelength, y = spc, colour = region, group = .rownames)
) +
  facet_grid(region ~ .)


## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Concentration profile: intensities at the first available wavelength value.  "

## ----ggplotc-01, fig.cap=CAPTION------------------------------------------------------------------
qplotc(flu)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Concentration profile: intensities at 410 nm.   "

## ----ggplotc-02, fig.cap=CAPTION------------------------------------------------------------------
qplotc(flu[ , , 410])

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Concentration profile with fitted line.  "

## ----ggplotc-03, fig.cap=CAPTION------------------------------------------------------------------
qplotc(flu[ , , 410]) + 
  geom_smooth(method = "lm", formula = y ~ x)

## -------------------------------------------------------------------------------------------------
set.seed(7)
faux_cell <- generate_faux_cell()

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False-colour map produced by `qplotmap()`{.r}.  "

## ----ggplotmap-01, fig.cap=CAPTION----------------------------------------------------------------
qplotmap(faux_cell[ , , 1200])

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False-colour map produced by `qplotmap()`{.r}: different color palette.  "

## ----ggplotmap-02, fig.cap=CAPTION----------------------------------------------------------------
qplotmap(faux_cell[ , , 1200]) +
    scale_fill_gradientn("Intensity", colours = matlab.palette())

## -------------------------------------------------------------------------------------------------
set.seed(1)
faux_cell <- generate_faux_cell()

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False-color map produced by `qplotmixmap()`{.r}: raw `faux_cell` spectra at 800, 1200, and 1500 $cm^{-1}.$    "

## ----qplotmixmap-01, fig.cap=CAPTION--------------------------------------------------------------
qplotmixmap(faux_cell[, , c(800, 1200, 1500)],
  purecol = c(matrix = "red", cell = "green", nucleus = "blue")
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False-color map of `faux_cell` spectra with base line removed.  "

## ----qplotmixmap-02, fig.cap=CAPTION--------------------------------------------------------------
faux_cell_2 <- faux_cell - spc_fit_poly_below(faux_cell)

qplotmixmap(faux_cell_2[, , c(800, 1200, 1500)],
  purecol = c(matrix = "red", cell = "green", nucleus = "blue")
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False-color map of pre-processed `faux_cell` spectra.  "

## ----qplotmixmap-03, fig.cap=CAPTION--------------------------------------------------------------
faux_cell_3 <- faux_cell_2
faux_cell_3 <- sweep(faux_cell_3, 1, apply(faux_cell_3, 1, mean), "/")
faux_cell_3 <- sweep(faux_cell_3, 2, apply(faux_cell_3, 2, quantile, 0.05), "-")

qplotmixmap(faux_cell_3[, , c(800, 1200, 1500)],
  purecol = c(matrix = "red", cell = "green", nucleus = "blue")
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Mean $\\pm$ standard deviation with package **ggplot2**.  "

## ----ggplotmeansd, fig.cap=CAPTION, eval=FALSE----------------------------------------------------
#  qplotspc(mean(faux_cell)) +
#    geom_ribbon(aes(
#      ymin = mean + sd,
#      ymax = mean - sd,
#      y = 0,
#      group = NA
#    ),
#      alpha = 0.25,
#      data = as.t.df(mean_sd(faux_cell))
#    )

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Plot separate regions of specra.  "

## ----ggplotspccut, fig.cap=CAPTION----------------------------------------------------------------
qplotspc(paracetamol / 1e4, wl.range = c(min ~ 1800, 2800 ~ max)) +
  scale_x_continuous(breaks = seq(0, 3200, 400))

## ----session-info-plotting, paged.print=FALSE-----------------------------------------------------
sessioninfo::session_info("hyperSpec")

