library(hySpc.testthat)
library(hySpc.ggplot2)

test_check("hySpc.ggplot2")
