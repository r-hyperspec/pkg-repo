## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----out.width="100%", echo=FALSE---------------------------------------------
knitr::include_graphics("figures/benchmark_time_plot.png")

## ----out.width="100%", echo=FALSE---------------------------------------------
knitr::include_graphics("figures/benchmark_speedup_plot.png")

