## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
# install.packages(c("future", "future.batchtools", "future.apply"))

## ----eval=FALSE---------------------------------------------------------------
# library(future.batchtools)
# library(future.apply)
# library(hySpc.hpc)
# 
# # Define the compute resources for EACH worker job
# # e.g., We want each worker to get 4 CPU cores and 8GB RAM per core.
# resources <- list(
#   ncpus = 4,
#   memory = 8000,
#   walltime = "02:00:00"
# )
# 
# # Tell the future framework to use Slurm for asynchronous jobs
# plan(batchtools_slurm, template = "slurm.tmpl", resources = resources)

## ----eval=FALSE---------------------------------------------------------------
# # Assume `spc_list` is a list of 100 hyperSpec objects
# spc_list <- load_my_hyperspectral_data()
# 
# # Define the smoothing function that will run on the cluster nodes
# smooth_wrapper <- function(spc) {
#   # -------------------------------------------------------------
#   # CRITICAL: THREAD MANAGEMENT
#   # We MUST tell Rust/Rayon to restrict its thread pool to the
#   # number of cores officially allocated to this job by Slurm.
#   # -------------------------------------------------------------
#   allocated_cores <- as.numeric(Sys.getenv("SLURM_CPUS_PER_TASK", unset = 1))
#   Sys.setenv(RAYON_NUM_THREADS = allocated_cores)
# 
#   # Now it is safe to run the high-performance Rust backend
#   # It will use exactly `allocated_cores` threads.
#   spc_smoothed <- graphSmooth(spc,
#                               width = 512,
#                               height = 512,
#                               alpha = 2.0,
#                               neighbors = 8)
# 
#   return(spc_smoothed)
# }
# 
# # Dispatch the jobs to the Slurm cluster asynchronously
# # future_lapply acts just like lapply, but distributes the work
# # across the compute nodes defined in our `plan()`.
# smoothed_results <- future_lapply(spc_list, smooth_wrapper)

