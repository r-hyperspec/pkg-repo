## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message=FALSE-----------------------------------------------------
library(hyperSpec)
library(hySpc.hpc)

## ----simulate-----------------------------------------------------------------
set.seed(123)
width <- 10
height <- 10
n_pixels <- width * height
n_bands <- 5

# Create a clean signal (e.g. a simple gradient)
clean_signal <- matrix(rep(1:n_pixels, n_bands), nrow = n_pixels) / n_pixels

# Add Gaussian noise
noisy_signal <- clean_signal + matrix(rnorm(n_pixels * n_bands, sd = 0.2), nrow = n_pixels)

# Wrap it in a hyperSpec object
spc_noisy <- new("hyperSpec", spc = noisy_signal)

## ----smooth-------------------------------------------------------------------
# Apply smoothing with alpha = 2.0 and 8-connectivity
spc_smoothed <- graphSmooth(spc_noisy, width, height, alpha = 2.0, neighbors = 8)

## ----plot, fig.width=6, fig.height=4------------------------------------------
# Extract the first wavelength band and reshape to a matrix for plotting
noisy_band1 <- matrix(spc_noisy[,,1]@data$spc, nrow = height, ncol = width)
smoothed_band1 <- matrix(spc_smoothed[,,1]@data$spc, nrow = height, ncol = width)

par(mfrow=c(1,2))
image(noisy_band1, main="Noisy Band 1", col=hcl.colors(12, "viridis"))
image(smoothed_band1, main="Smoothed Band 1", col=hcl.colors(12, "viridis"))

## ----strong_smooth------------------------------------------------------------
# Stronger smoothing
spc_strong <- graphSmooth(spc_noisy, width, height, alpha = 10.0, neighbors = 8)
strong_band1 <- matrix(spc_strong[,,1]@data$spc, nrow = height, ncol = width)

par(mfrow=c(1,1))
image(strong_band1, main="Strongly Smoothed (alpha = 10.0)", col=hcl.colors(12, "viridis"))

