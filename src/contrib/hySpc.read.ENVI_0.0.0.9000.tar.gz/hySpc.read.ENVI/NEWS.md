# hySpc.read.ENVI

## Acknowledgements
The `hyperSpec` team gratefully acknowledges support from the Google Summer of Code program, which sponsored student Sang Truong during summer 2021.
Sang and the team carried out a significant overhaul of `hyperSpec` which led to this release.

# Version

## User-visible Changes

### Bug Fixes
### Breaking Changes
### New Functions

## Internal Changes
