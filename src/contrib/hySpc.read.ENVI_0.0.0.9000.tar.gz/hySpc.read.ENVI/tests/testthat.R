library(hySpc.testthat)
library(hySpc.read.ENVI)

test_check("hySpc.read.ENVI")
