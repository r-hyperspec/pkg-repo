# C. Beleites
# run all tests attached to objects
hySpc.testthat::unittest("hySpc.read.ENVI", standalone = FALSE)
