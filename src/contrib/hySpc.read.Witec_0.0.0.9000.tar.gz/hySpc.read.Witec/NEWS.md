# hySpc.read.Witec x.x.x 2020-xx-xx

## Misc.
* First release!
