library(testthat)
library(hySpc.read.Witec)

test_check("hySpc.read.Witec")
