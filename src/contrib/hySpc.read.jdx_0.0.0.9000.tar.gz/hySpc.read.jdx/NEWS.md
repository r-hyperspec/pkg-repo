# hySpc.read.jdx 0.0.x 2021-xx-xx

## Misc

* First release.

## Acknowledgements

* The `hyperSpec` team gratefully acknowledges support from the Google Summer of Code program, which sponsored student Sang Truong during summer 2021. Sang and the team carried out a significant overhaul of `hyperSpec` which led to this release.
