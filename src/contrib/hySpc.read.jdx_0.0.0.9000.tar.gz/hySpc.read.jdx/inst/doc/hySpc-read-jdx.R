## ----cleanup-hyperspec, include = FALSE---------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hySpc.read.jdx)
library("knitr")

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporary options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes = getOption("show_reviewers_notes", TRUE)

## ----bib, echo = FALSE, paged.print = FALSE-------------------------------------------------------
dir.create("resources", showWarnings = FALSE)
knitr::write_bib(
  c("hyperSpec"),
  file = "resources/intro-pkg.bib"
)

## ---- echo = FALSE, results = "asis"--------------------------------------------------------------
res <- knitr::knit_child("list-of-vignettes.md", quiet = TRUE)
cat(res, sep = '\n')

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "IR spectrum of Smart Balance Original spread, a butter substitute.  "

## ----demo_read_plot, fig.cap = CAPTION------------------------------------------------------------
sbo <- system.file("extdata", "SBO.jdx", package = "readJDX")
data <- read_jdx(sbo)
spc <- data[[2]]
plot(spc)

## ----metadata-------------------------------------------------------------------------------------
meta <- data[[1]]
head(meta, n = 40L)

