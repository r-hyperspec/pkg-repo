## ----cleanup-hyperspec, include = FALSE---------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hySpc.read.jdx)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporary options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes = getOption("show_reviewers_notes", TRUE)

## ----bib, echo = FALSE, paged.print = FALSE-------------------------------------------------------
dir.create("resources", showWarnings = FALSE)
knitr::write_bib(
  c("hyperSpec"),
  file = "resources/intro-pkg.bib"
)

## ---- echo = FALSE, results = "asis"--------------------------------------------------------------
res <- knitr::knit_child("list-of-vignettes.md", quiet = TRUE)
cat(res, sep = '\n')

## ---- eval = FALSE--------------------------------------------------------------------------------
#  library(hySpc.read.jdx)
#  
#  # 2 examples for case 1 (single spectrum such as IR, Raman, UV, processed/real 1D NMR, etc)
#  miniDIFUP_file <- system.file("extdata", "MiniDIFDUP.JDX", package = "readJDX")
#  miniDIFUP <- hySpc.read.jdx::read_jdx(miniDIFUP_file)
#  
#  sbo_file <- system.file("extdata", "SBO.JDX", package = "readJDX")
#  sbo <- hySpc.read.jdx::read_jdx(sbo_file)
#  
#  # An example for case 2 (spectrum and the real and imaginary parts of 1D NMR spectrum)
#  pcrf_file <- system.file("extdata", "PCRF.jdx", package = "readJDX")
#  pcrf <- hySpc.read.jdx::read_jdx(pcrf_file)

