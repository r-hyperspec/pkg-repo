library(hySpc.testthat)
library(hySpc.read.jdx)

test_check("hySpc.read.jdx")
