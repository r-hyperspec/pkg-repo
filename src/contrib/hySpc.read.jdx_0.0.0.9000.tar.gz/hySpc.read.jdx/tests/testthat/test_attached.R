# C. Beleites
# run all tests attached to objects
library(hySpc.testthat)
hySpc.testthat::unittest("hySpc.read.jdx", standalone = FALSE)
