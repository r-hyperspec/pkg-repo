# hySpc.read.jdx 1.0.0.0 2021-08-12

## Misc
* First release.

## Acknowledgements

* The `hyperSpec` team gratefully acknowledges support from the Google Summer of Code program, which sponsored student Sang Truong during summer 2021. Sang and the team carried out a significant overhaul of `hyperSpec` which included the development of this package.
