library(hySpc.read.jdx)
library(testthat)

test_check("hySpc.read.jdx")
