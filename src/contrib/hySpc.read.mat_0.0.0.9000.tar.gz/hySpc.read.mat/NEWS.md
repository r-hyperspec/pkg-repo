# hySpc.read.mat

## Acknowledgements
The `hyperSpec` team gratefully acknowledges support from the Google Summer of Code program, which sponsored student Erick Oduniyi during summer 2020 and Sang Truong during summer 2021.
Erick, Sang, and the team carried out a significant overhaul of `hyperSpec` which led to this release.

# Version

## User-visible Changes

### Bug Fixes
### Breaking Changes
### New Functions

## Internal Changes
