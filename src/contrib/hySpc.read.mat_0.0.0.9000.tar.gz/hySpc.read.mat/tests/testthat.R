library(hySpc.testthat)
library(hySpc.read.mat)

test_check("hySpc.read.mat")
