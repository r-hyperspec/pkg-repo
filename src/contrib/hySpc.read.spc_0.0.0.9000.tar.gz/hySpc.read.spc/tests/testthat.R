library(hySpc.testthat)
library(hySpc.read.spc)

test_check("hySpc.read.spc")
