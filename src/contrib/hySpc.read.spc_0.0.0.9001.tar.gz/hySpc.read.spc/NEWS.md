# hySpc.read.spc

## Acknowledgements
The `hyperSpec` team gratefully acknowledges support from the Google Summer of Code program, which sponsored student Erick Oduniyi during summer 2020.
Erick and the team carried out a significant overhaul of `hyperSpec` which led to this release.

# Version

## User-visible Changes

### Bug Fixes
### Breaking Changes
### New Functions

## Internal Changes
