#' @keywords internal
#'
#' @import hyperSpec
#' @import hySpc.testthat
#'
#' @importFrom methods is
#' @importFrom utils maintainer
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL
