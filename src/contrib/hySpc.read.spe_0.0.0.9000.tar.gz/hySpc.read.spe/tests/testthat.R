library(testthat)
library(hySpc.read.spe)

test_check("hySpc.read.spe")
