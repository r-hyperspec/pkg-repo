.fileio.optional <- hyperSpec:::.fileio.optional
