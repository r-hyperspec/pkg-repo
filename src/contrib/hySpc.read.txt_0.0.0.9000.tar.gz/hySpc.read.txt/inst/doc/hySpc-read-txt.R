## ----cleanup-fileio, include = FALSE------------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)
library(R.matlab)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporaty options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes = getOption("show_reviewers_notes", TRUE)

## ---- echo=FALSE----------------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# If all necessary datasets are coppied into "fileio" directory,
# the examples are run. Otherwise they are disabled.
if (dir.exists("fileio") && length(dir("fileio")) != 0) {
  # To test locally if the exaples still work
  knit_eval <- TRUE
  # message("Code evaluation in fileio.Rmd enabled!")

} else {
  # Do not run code
  knit_eval <- FALSE
  warning("Code evaluation in fileio.Rmd DISABLED!")
}

knitr::opts_chunk$set(eval = knit_eval)
# FIXME: this is not a good way to do in vignette,
# but we should come up with ideas how to cope
# with big files in this situation.
# ----------------------------------------------------------------------------

## ----bib, echo=FALSE, paged.print=FALSE, eval=TRUE------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c(
    "hyperSpec",
    "R.matlab"
  ),
  file = "resources/fileio-pkg.bib",
  prefix = "R_"
)

## -------------------------------------------------------------------------------------------------
library(hyperSpec)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  spc <- new("hyperSpec", spc, wavelength, data, labels)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  spc <- new("hyperSpec", spc, wavelength, data, labels)

## ----array----------------------------------------------------------------------------------------
data <- array(1:24, 4:2)
wl <- c(550, 630)
x <- c(1000, 1200, 1400)
y <- c(1800, 1600, 1400, 1200)
data

## ----array-import---------------------------------------------------------------------------------
d <- dim(data)
dim(data) <- c(d[1] * d[2], d[3])

x <- rep(x, each = d[1])
y <- rep(y, d[2])

spectra <- new("hyperSpec",
  spc = data,
  data = data.frame(x, y), wavelength = wl
)

## -------------------------------------------------------------------------------------------------
y <- seq_len(d[1])
x <- seq_len(d[2])

## ----readcollapse---------------------------------------------------------------------------------
files <- Sys.glob("fileio/spc.Kaisermap/*.spc")
files <- files[seq(1, length(files), by = 2)] # import low wavenumber region only
spc <- lapply(files, read.spc)
length(spc)
spc[[1]]
spc <- collapse(spc)
spc

## ----read_txt_t-----------------------------------------------------------------------------------
file <- read.table("fileio/txt.t/Triazine_5_31.txt", header = TRUE, dec = ",", sep = "\t")

triazine <- new("hyperSpec",
  wavelength = file[, 1], spc = t(file[, -1]),
  data = data.frame(sample = colnames(file[, -1])),
  labels = list(
    .wavelength = expression(2 * theta / degree),
    spc = "I / a.u."
  )
)
triazine

## ----include=FALSE--------------------------------------------------------------------------------
# TODO: A better caption may be needed.
CAPTION <- "Spectra of triazine. "

## ----plot-triazine, fig.cap=CAPTION---------------------------------------------------------------
plot(triazine[1])

## ----nist-aes-------------------------------------------------------------------------------------
file <- readLines("fileio/NIST/mercurytable2.htm")
# file <- readLines("http://physics.nist.gov/PhysRefData/Handbook/Tables/mercurytable2.htm")

file <- file[-(1:grep("Intensity.*Wavelength", file) - 1)]
file <- file[1:(grep("</pre>", file) [1] - 1)]
file <- gsub("<[^>]*>", "", file)
file <- file[!grepl("^[[:space:]]+$", file)]

colnames <- file[1]
colnames <- gsub("[[:space:]][[:space:]]+", "\t", file[1])
colnames <- strsplit(colnames, "\t")[[1]]
if (!all(colnames == c("Intensity", "Wavelength (&Aring;)", "Spectrum", "Ref. "))) {
  stop("file format changed!")
}

tablestart <- grep("^[[:blank:]]*[[:alpha:]]+$", file) + 1
tableend <- c(tablestart[-1] - 2, length(file))
tables <- list()
for (t in seq_along(tablestart)) {
  tmp <- file[tablestart[t]:tableend[t]]
  tables[[t]] <- read.fwf(textConnection(tmp), c(5, 8, 12, 15, 9))
  colnames(tables[[t]]) <- c("Intensity", "persistent", "Wavelength", "Spectrum", "Ref. ")
  tables[[t]]$type <- gsub("[[:space:]]", "", file[tablestart[t] - 1])
}
tables <- do.call(rbind, tables)
levels(tables$Spectrum) <- gsub(" ", "", levels(tables$Spectrum))

Hg.AES <- list()
for (s in levels(as.factor(tables$Spectrum))) {
  Hg.AES[[s]] <- new("hyperSpec",
    wavelength = tables$Wavelength[tables$Spectrum == s],
    spc = tables$Intensity[tables$Spectrum == s],
    data = data.frame(Spectrum = s),
    label = list(
      .wavelength = expression(lambda / ring(A)),
      spc = "I"
    )
  )
}

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Extracted spectra from of the Hg strong lines file."

## ----plot-hg-aes, fig.cap=CAPTION-----------------------------------------------------------------
plot(collapse(Hg.AES), lines.args = list(type = "h"), col = 1:2)

## -------------------------------------------------------------------------------------------------
library(R.matlab)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  spc.mat <- readMat("fileio/spectra.mat")

## ----eval=FALSE-----------------------------------------------------------------------------------
#  install.packages("Rcompression", repos = "http://www.omegahat.org/R")

## -------------------------------------------------------------------------------------------------
read.asc.Andor("fileio/asc.Andor/ASCII-Andor-Solis.asc")

## ----comment="", eval=TRUE, echo=FALSE, class.output="add-border sourceCode r"--------------------
writeLines(readLines("read_txt_PerkinElmer.R"))

## ----read-fileformats-data, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------
# ----------------------------------------------------------------------------
options(knitr.kable.NA = '')
# ----------------------------------------------------------------------------
fileformats <- read.table("fileio--fileformats.txt", header = TRUE, sep = "|",
  strip.white = TRUE, na.strings = "")

fileformats$html_unfriendly_link <- NULL

fileformats$Function <-
  ifelse(
    is.na(fileformats$Function),
    "",
   paste0("`", fileformats$Function, "()`{.r}")
  )

fileformats$Link <- ifelse(
  is.na(fileformats$Link),
  "",
  paste0("\\@ref(sec:", fileformats$Link, ")")
)

rownames(fileformats) <- NULL

## ----by-format, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------------------
kbl1 <- knitr::kable(
  fileformats[order(fileformats$Format)[!is.na(fileformats$Format)], ]
  , format = "html"
  , row.names = FALSE
  # , caption = "File Import Functions by Format.  "
)

kableExtra::pack_rows(kbl1, index = table(fileformats$Format))

## ----by-manufacturer, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------------
kbl2 <- knitr::kable(
  fileformats[order(fileformats$Manufacturer), ]
  , format = "html"
  , row.names = FALSE
  # , caption = "File Import Functions by Manufacturer.  "
)

kableExtra::pack_rows(kbl2, index = table(fileformats$Manufacturer))

## ----by-spectroscopy, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------------
kbl <- knitr::kable(
  fileformats[order(fileformats$Spectroscopy), ]
  , format = "html"
  , row.names = FALSE
  # , caption = "File Import Functions by Spectroscopy.  "
)

kableExtra::pack_rows(kbl, index = table(fileformats$Spectroscopy))

## ----session-info-fileio, paged.print=FALSE, eval=TRUE--------------------------------------------
sessioninfo::session_info()

