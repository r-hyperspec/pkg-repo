library(testthat)
library(hySpc.read.txt)

test_check("hySpc.read.txt")
