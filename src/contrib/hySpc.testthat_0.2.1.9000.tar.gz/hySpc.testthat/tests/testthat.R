library(testthat)
library(hySpc.testthat)

test_check("hySpc.testthat")
