# C. Beleites
# run all tests attached to objects
unittest("hySpc.testthat", standalone = FALSE)