Data in "paracetamol.txt", "laser.txt.gz", "chondro.gz" are registered with Renishaw equipment.

Data in directory "flu" are registered with PerkinElmer equipment.

"BARBITUATES.SPC" contains data in Thermo Galactic's `.spc` file format.
