library(hySpc.testthat)
library(hyperSpec)

test_check("hyperSpec")
