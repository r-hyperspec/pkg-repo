# @concept constants
#
.wn.shift <- expression(Delta * tilde(nu) / cm^-1)
.wn <- expression(tilde(nu) / cm^-1)
.wl <- expression(lambda / nm)
