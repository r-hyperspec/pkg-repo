## ----cleanup-baseline, include = FALSE----------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporaty options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes = getOption("show_reviewers_notes", TRUE)

## ----bib, echo=FALSE, paged.print=FALSE-----------------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c(
    "hyperSpec",
    "baseline"
  ),
  file = "resources/baseline-pkg.bib"
)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  spc.fit.poly(fit.to, apply.to = fit.to, poly.order = 1)
#  
#  spc.fit.poly.below(fit.to, apply.to = fit.to, poly.order = 1, npts.min = NULL, noise = 0)

## -------------------------------------------------------------------------------------------------
# Load Raman spectra
file <- system.file("extdata/chondro_mini.rds", package = "hyperSpec")
chondro_mini <- readRDS(file)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Fitting a linear baseline through two points.
If the signal to noise ratio is not ideal, wavelengths that work fine for one spectrum (black) may not be appropriate for another (red). "

## ----classical, fig.cap=CAPTION-------------------------------------------------------------------
bl <- spc.fit.poly(chondro_mini[, , c(633, 1788)], chondro_mini)

plot(chondro_mini, plot.args = list(ylim = c(200, 600)), col = 1:2)
plot(chondro_mini[, , c(633, 1788)],
  add = TRUE, col = 1:2,
  lines.args = list(type = "p", pch = 20)
)
plot(bl, add = TRUE, col = 1:2)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Iterative fitting of the baseline. The dots give the supporting points for the next iteration's baseline, color: iterations.  "

## ----iter, fig.cap=CAPTION, message=FALSE, warning=FALSE------------------------------------------
bl <- spc.fit.poly.below(chondro_mini[1], poly.order = 1, max.iter = 8, npts.min = 2, debuglevel = 3L)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Influence of `fit.to`{.r} on the baseline polynomial.
The black baseline is fit to the spectral range 1700 - 1750 $cm^{-1}$, the blue to 1720 - 1750 $cm^{-1}$ only.  "

## ----spectralrange, fig.cap=CAPTION---------------------------------------------------------------
plot(chondro_mini[1, , 1700 ~ 1750],
  lines.args = list(type = "b"),
  plot.args = list(ylim = range(chondro_mini[1, , 1700 ~ 1750]) + c(-50, 0))
)

bl <- spc.fit.poly.below(chondro_mini[1, , 1700 ~ 1750], NULL, poly.order = 1)
abline(bl[[]], col = "black")

plot(
  chondro_mini[1, , 1720 ~ 1750],
  lines.args = list(type = "p", pch = 19, cex = .6),
  col = "blue",
  add = T
)

bl <- spc.fit.poly.below(chondro_mini[1, , 1720 ~ 1750], NULL, poly.order = 1)
abline(bl[[]], col = "blue")

## ----fit-apply------------------------------------------------------------------------------------
system.time(spc.fit.poly.below(chondro_mini, NULL, npts.min = 20))
system.time(spc.fit.poly.below(chondro_mini[, , c(min ~ 700, 1700 ~ max)], NULL, npts.min = 20))

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Baseline polynomial fit to the first spectrum of the chondro_mini data set of order 0 -- 2 (left to right).
The dots indicate the points used for the fitting of the polynomial.  "

## ----figorder0, fig.cap=CAPTION-------------------------------------------------------------------
bl <- spc.fit.poly.below(chondro_mini[1], poly.order = 0, debuglevel = 2, max.iter = 5)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Baseline polynomial fit to the first spectrum of the chondro_mini data set of order 0 -- 2 (left to right).
The dots indicate the points used for the fitting of the polynomial.  "

## ----figorder1, fig.cap=CAPTION-------------------------------------------------------------------
bl <- spc.fit.poly.below(chondro_mini[1], poly.order = 1, debuglevel = 2, max.iter = 5)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Baseline polynomial fit to the first spectrum of the chondro_mini data set of order 0 -- 2 (left to right).
The dots indicate the points used for the fitting of the polynomial.  "

## ----figorder2, fig.cap=CAPTION-------------------------------------------------------------------
bl <- spc.fit.poly.below(chondro_mini[1], poly.order = 2, debuglevel = 2, max.iter = 5)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Iterative fitting of the baseline with noise level.
Effects of the noise parameter on the baseline of a spectrum consisting only of noise and offset: without giving `noise`{.r} the resulting baseline (black) is clearly too low.
A noise level of 4 results in the blue baseline. "

## ----fig3, fig.cap=CAPTION, message=FALSE---------------------------------------------------------
spc <- new("hyperSpec", spc = matrix(rnorm(100, mean = 100, sd = 2), ncol = 100))
noise <- 4
spc.fit.poly.below(spc, poly.order = 0, noise = noise, debuglevel = 2)
plot(spc.fit.poly.below(spc, poly.order = 0), col = "black", add = T)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Iterative fitting of the baseline with noise level.
The baseline fitting with noise level on the complete spectrum.
Colour: iterations, dots: supporting points for the respectively next baseline.
Dashed: baseline plus noise.
All points above this line are excluded from the next iteration.  "

## ----fig4, fig.cap=CAPTION, message=FALSE---------------------------------------------------------
bl <- spc.fit.poly.below(chondro_mini[1], poly.order = 1, noise = 15, max.iter = 8, debuglevel = 3L)

## -------------------------------------------------------------------------------------------------
bl <- spc.rubberband(paracetamol[, , 175 ~ 1800], noise = 300, df = 20)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Rubberband baselines for the paracetamol spectrum:`paracetamol`{.r} with the `rubberband()`{.r} fitted baseline.  "

## ----rubberband-raw, fig.cap=CAPTION--------------------------------------------------------------
plot(paracetamol[, , 175 ~ 1800])
plot(bl, add = TRUE, col = 2)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Rubberband baselines for the paracetamol spectrum: corrected spectrum.  "

## ----rubberband, fig.cap=CAPTION------------------------------------------------------------------
plot(paracetamol[, , 175 ~ 1800] - bl)

## ----bent-rubberband------------------------------------------------------------------------------
bend <- 5e4 * wl.eval(paracetamol[, , 175 ~ 1800], function(x) x^2, normalize.wl = normalize01)
bl <- spc.rubberband(paracetamol[, , 175 ~ 1800] + bend) - bend

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Rubberband baselines for the paracetamol spectrum after bending: bent `paracetamol`{.r} spectrum and rubberband baseline. "

## ----rubberband-bent-raw, fig.cap=CAPTION---------------------------------------------------------
plot(paracetamol[, , 175 ~ 1800] + bend)
plot(bl + bend, add = T, col = 2)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Rubberband baselines for the paracetamol spectrum after bendin: corrected spectrum.  "

## ----rubberband-bent-corrected, fig.cap=CAPTION---------------------------------------------------
plot(paracetamol[, , 175 ~ 1800] - bl)

## ----session-info-baseline, paged.print=FALSE-----------------------------------------------------
sessioninfo::session_info("hyperSpec")

