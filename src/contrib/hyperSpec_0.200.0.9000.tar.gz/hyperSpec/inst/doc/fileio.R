## ----cleanup-fileio, include = FALSE--------------------------------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)
library(R.matlab)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporaty options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes <- getOption("show_reviewers_notes", TRUE)

## ---- echo=FALSE----------------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# If all necessary datasets are coppied into "fileio" directory,
# the examples are run. Otherwise they are disabled.
if (dir.exists("fileio") && length(dir("fileio")) != 0) {
  # To test locally if the exaples still work
  knit_eval <- TRUE
  # message("Code evaluation in fileio.Rmd enabled!")

} else {
  # Do not run code
  knit_eval <- FALSE
  warning("Code evaluation in fileio.Rmd DISABLED!")
}

knitr::opts_chunk$set(eval = knit_eval)
# FIXME: this is not a good way to do in vignette,
# but we should come up with ideas how to cope
# with big files in this situation.
# ----------------------------------------------------------------------------

## ----bib, echo=FALSE, paged.print=FALSE, eval=TRUE------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c(
    "hyperSpec",
    "R.matlab"
  ),
  file = "resources/fileio-pkg.bib",
  prefix = "R-"
)

## ---- echo = FALSE, results = "asis"--------------------------------------------------------------
#  res <- knitr::knit_child("list-of-vignettes.md", quiet = TRUE)
#  cat(res, sep = "\n")

## -------------------------------------------------------------------------------------------------
#  library(hyperSpec)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  spc <- new("hyperSpec", spc, wavelength, data, labels)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  spc <- new("hyperSpec", spc, wavelength, data, labels)

## ----array----------------------------------------------------------------------------------------
#  data <- array(1:24, 4:2)
#  wl <- c(550, 630)
#  x <- c(1000, 1200, 1400)
#  y <- c(1800, 1600, 1400, 1200)
#  data

## ----array-import---------------------------------------------------------------------------------
#  d <- dim(data)
#  dim(data) <- c(d[1] * d[2], d[3])
#  
#  x <- rep(x, each = d[1])
#  y <- rep(y, d[2])
#  
#  spectra <- new("hyperSpec",
#    spc = data,
#    data = data.frame(x, y), wavelength = wl
#  )

## -------------------------------------------------------------------------------------------------
#  y <- seq_len(d[1])
#  x <- seq_len(d[2])

## ----readcollapse---------------------------------------------------------------------------------
#  files <- Sys.glob("fileio/spc.Kaisermap/*.spc")
#  files <- files[seq(1, length(files), by = 2)] # import low wavenumber region only
#  spc <- lapply(files, read.spc)
#  length(spc)
#  spc[[1]]
#  spc <- collapse(spc)
#  spc

## ----read.txt.t-----------------------------------------------------------------------------------
#  file <- read.table("fileio/txt.t/Triazine 5_31.txt", header = TRUE, dec = ",", sep = "\t")
#  
#  triazine <- new("hyperSpec",
#    wavelength = file[, 1], spc = t(file[, -1]),
#    data = data.frame(sample = colnames(file[, -1])),
#    labels = list(
#      .wavelength = expression(2 * theta / degree),
#      spc = "I / a.u."
#    )
#  )
#  triazine

## ----include=FALSE--------------------------------------------------------------------------------
#  # TODO: A better caption may be needed.
#  CAPTION <- "Spectra of triazine. "

## ----plot-triazine, fig.cap=CAPTION---------------------------------------------------------------
#  plot(triazine[1])

## ----nist-aes-------------------------------------------------------------------------------------
#  file <- readLines("fileio/NIST/mercurytable2.htm")
#  # file <- readLines("http://physics.nist.gov/PhysRefData/Handbook/Tables/mercurytable2.htm")
#  
#  file <- file[-(1:grep("Intensity.*Wavelength", file) - 1)]
#  file <- file[1:(grep("</pre>", file) [1] - 1)]
#  file <- gsub("<[^>]*>", "", file)
#  file <- file[!grepl("^[[:space:]]+$", file)]
#  
#  colnames <- file[1]
#  colnames <- gsub("[[:space:]][[:space:]]+", "\t", file[1])
#  colnames <- strsplit(colnames, "\t")[[1]]
#  if (!all(colnames == c("Intensity", "Wavelength (&Aring;)", "Spectrum", "Ref. "))) {
#    stop("file format changed!")
#  }
#  
#  tablestart <- grep("^[[:blank:]]*[[:alpha:]]+$", file) + 1
#  tableend <- c(tablestart[-1] - 2, length(file))
#  tables <- list()
#  for (t in seq_along(tablestart)) {
#    tmp <- file[tablestart[t]:tableend[t]]
#    tables[[t]] <- read.fwf(textConnection(tmp), c(5, 8, 12, 15, 9))
#    colnames(tables[[t]]) <- c("Intensity", "persistent", "Wavelength", "Spectrum", "Ref. ")
#    tables[[t]]$type <- gsub("[[:space:]]", "", file[tablestart[t] - 1])
#  }
#  tables <- do.call(rbind, tables)
#  levels(tables$Spectrum) <- gsub(" ", "", levels(tables$Spectrum))
#  
#  Hg.AES <- list()
#  for (s in levels(as.factor(tables$Spectrum))) {
#    Hg.AES[[s]] <- new("hyperSpec",
#      wavelength = tables$Wavelength[tables$Spectrum == s],
#      spc = tables$Intensity[tables$Spectrum == s],
#      data = data.frame(Spectrum = s),
#      label = list(
#        .wavelength = expression(lambda / ring(A)),
#        spc = "I"
#      )
#    )
#  }

## ----include=FALSE--------------------------------------------------------------------------------
#  CAPTION <- "Extracted spectra from of the Hg strong lines file."

## ----plot-hg-aes, fig.cap=CAPTION-----------------------------------------------------------------
#  plot(collapse(Hg.AES), lines.args = list(type = "h"), col = 1:2)

## -------------------------------------------------------------------------------------------------
#  library(R.matlab)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  spc.mat <- readMat("fileio/spectra.mat")

## ----eval=FALSE-----------------------------------------------------------------------------------
#  install.packages("Rcompression", repos = "http://www.omegahat.org/R")

## ----read.mat.Cytospec-blocks---------------------------------------------------------------------
#  read.mat.Cytospec("fileio/mat.cytospec/cytospec.mat", blocks = TRUE)

## ----read.mat.Cytospec----------------------------------------------------------------------------
#  read.mat.Cytospec("fileio/mat.cytospec/cytospec.mat", blocks = 1)

## ----read.ENVI------------------------------------------------------------------------------------
#  spc <- read.ENVI("fileio/ENVI/example2.img")
#  spc

## -------------------------------------------------------------------------------------------------
#  read.spc("fileio/spc.Kaisermap/ebroAVII.spc", keys.hdr2data = TRUE)

## -------------------------------------------------------------------------------------------------
#  read.spc("fileio/spc.Kaisermap/ebroAVII.spc", keys.log2data = TRUE)

## ----read.spc.list, eval=FALSE, include=FALSE-----------------------------------------------------
#  barbiturates <- read.spc(system.file("extdata/BARBITUATES.SPC", package = "hyperSpec"))

## ----read.spc.list-old----------------------------------------------------------------------------
#  barbiturates <- read.spc("fileio/spc/BARBITUATES.SPC")

## -------------------------------------------------------------------------------------------------
#  class(barbiturates)

## -------------------------------------------------------------------------------------------------
#  length(barbiturates)

## -------------------------------------------------------------------------------------------------
#  barbiturates <- collapse(barbiturates, collapse.equal = FALSE)
#  barbiturates

## -------------------------------------------------------------------------------------------------
#  barbiturates[[, , 25 ~ 30]]

## ----eval=FALSE-----------------------------------------------------------------------------------
#  header <- list(
#    samples = 64 * no.images.in.row,
#    lines = 64 * no.images.in.column,
#    bands = no.data.points.per.spectrum,
#    `data type` = 4,
#    interleave = "bip"
#  )

## ----readENVINicolet------------------------------------------------------------------------------
#  spc <- read.ENVI.Nicolet("fileio/ENVI/example2.img", nicolet.correction = TRUE)
#  spc ## dummy sample with all intensities zero

## ----Kaiser.txt.comma-----------------------------------------------------------------------------
#  ## 1. import as character
#  tmp <- scan("fileio/txt.Kaiser/test-lo-4.txt", what = rep("character", 4), sep = ",")
#  tmp <- matrix(tmp, nrow = 4)
#  
#  ## 2. concatenate every two columns by a dot
#  wl <- apply(tmp[1:2, ],  2, paste, collapse = ".")
#  spc <- apply(tmp[3:4, ], 2, paste, collapse = ".")
#  
#  ## 3. convert to numeric and create hyperSpec objectne, though).
#  
#  spc <- new("hyperSpec", spc = as.numeric(spc), wavelength = as.numeric(wl))
#  spc

## ----readspcKaiserMap-----------------------------------------------------------------------------
#  files <- Sys.glob("fileio/spc.Kaisermap/*.spc")
#  spc.low  <- read.spc.KaiserMap(files[seq(1, length(files), by = 2)])
#  spc.high <- read.spc.KaiserMap(files[seq(2, length(files), by = 2)])
#  wl(spc.high) <- wl(spc.high) + 1340
#  spc

## ----read.txt.Renishaw----------------------------------------------------------------------------
#  paracetamol <- read.txt.Renishaw("fileio/txt.Renishaw/paracetamol.txt", "spc")
#  paracetamol

## -------------------------------------------------------------------------------------------------
#  read.txt.Renishaw("fileio/txt.Renishaw/laser.txt.gz", data = "ts")

## ----read.txt.Renishaw-file-----------------------------------------------------------------------
#  read.txt.Renishaw("fileio/txt.Renishaw/chondro.txt", nlines = 1e5, nspc = 875)

## ----read.txt.Renishaw-compressed, results='hide'-------------------------------------------------
#  read.txt.Renishaw("fileio/txt.Renishaw/chondro.gz")
#  read.txt.Renishaw("fileio/txt.Renishaw/chondro.xz")
#  read.txt.Renishaw("fileio/txt.Renishaw/chondro.lzma")
#  read.txt.Renishaw("fileio/txt.Renishaw/chondro.gz")
#  read.txt.Renishaw("fileio/txt.Renishaw/chondro.bz2")
#  read.zip.Renishaw("fileio/txt.Renishaw/chondro.zip")

## ----Horiba---------------------------------------------------------------------------------------
#  spc <- read.txt.Horiba("fileio/txt.HoribaJobinYvon/ts.txt",
#    cols = list(
#      t = "t / s", spc = "I / a.u.",
#      .wavelength = expression(Delta * tilde(nu) / cm^-1)
#    )
#  )
#  spc

## ----testHoriba-1---------------------------------------------------------------------------------
#  spc <- read.txt.Horiba.xy("fileio/txt.HoribaJobinYvon/map.txt")
#  if (any(dim(spc) != c(141, 4, 616)) ||
#    any(abs(spc) < .Machine$double.eps^.5) ||
#    is.null(spc$x) || any(is.na(spc$x)) ||
#    is.null(spc$y) || any(is.na(spc$y)) ||
#    length(setdiff(wl(spc), 1:616)) == 0L) {
#    stop("error in testing read.txt.Horiba.xy. Please contact ", maintainer("hyperSpec"))
#  }
#  spc

## ----testHoriba-2---------------------------------------------------------------------------------
#  spc <- read.txt.Horiba.t("fileio/txt.HoribaJobinYvon/ts.txt")
#  if (any(dim(spc) != c(100, 3, 1024)) ||
#    is.null(spc$t) || any(is.na(spc$t)) ||
#    length(setdiff(wl(spc), 1:1024)) == 0L) {
#    stop("error in testing read.txt.Horiba.xy. Please contact ", maintainer("hyperSpec"))
#  }
#  
#  spc
#  rm(spc)

## -------------------------------------------------------------------------------------------------
#  read.asc.Andor("fileio/asc.Andor/ASCII-Andor-Solis.asc")

## ----witec-spc, results='hide'--------------------------------------------------------------------
#  read.spc("fileio/spc.Witec/Witec-timeseries.spc")
#  read.spc("fileio/spc.Witec/Witec-Map.spc")

## ----witec-dat, results='hide'--------------------------------------------------------------------
#  read.dat.Witec("fileio/txt.Witec/Witec-timeseries-x.dat")
#  read.dat.Witec(
#    filex = "fileio/txt.Witec/Witec-Map-x.dat",
#    points.per.line = 5, lines.per.image = 5, type = "map"
#  )

## ----witec-txt, include=FALSE---------------------------------------------------------------------
#  read.txt.Witec("fileio/txt.Witec/Witec-timeseries_no.txt")

## ----witec-txt-error, echo=FALSE------------------------------------------------------------------
#  cat("Error in scan(file, what, nmax, sep, dec, quote, skip, nlines, na.strings,  :
#    scan() expected 'a real', got 'rel.'")

## ----witec-txt-textfiles, include=FALSE-----------------------------------------------------------
#  headline <- c(
#    "with exported labels and units headerlines:",
#    "\nwith exported labels headerline:",
#    "\nwith exported units headerline:",
#    "\nwithout headerline:"
#  )
#  files <- c(
#    "fileio/txt.Witec/Witec-timeseries_full.txt",
#    "fileio/txt.Witec/Witec-timeseries_label.txt",
#    "fileio/txt.Witec/Witec-timeseries_unit.txt",
#    "fileio/txt.Witec/Witec-timeseries_no.txt"
#  )
#  
#  for (f in seq_along(files)) {
#    cat(headline[f], "\n")
#    tmp <- format(as.matrix(read.table(files[f], sep = "\t")[1:4, 1:3]))
#    apply(tmp, 1, function(l) cat(l, "\n"))
#  }

## ----witec-txt-map, include=FALSE-----------------------------------------------------------------
#  read.txt.Witec("fileio/txt.Witec/Witec-Map_full.txt",  type = "map", hdr.label = TRUE, hdr.units = TRUE)
#  
#  read.txt.Witec("fileio/txt.Witec/Witec-Map_label.txt", type = "map", hdr.label = TRUE, hdr.units = FALSE)
#  
#  read.txt.Witec("fileio/txt.Witec/Witec-Map_unit.txt",  type = "map", hdr.label = FALSE, hdr.units = TRUE)
#  
#  read.txt.Witec("fileio/txt.Witec/Witec-Map_unit.txt",
#    type = "map", hdr.label = FALSE, hdr.units = TRUE,
#    points.per.line = 5
#  )
#  
#  read.txt.Witec("fileio/txt.Witec/Witec-Map_no.txt", type = "map", hdr.label = FALSE, hdr.units = FALSE)
#  
#  read.txt.Witec("fileio/txt.Witec/Witec-Map_no.txt",
#    type = "map", hdr.label = FALSE, hdr.units = FALSE,
#    lines.per.image = 5
#  )
#  
#  read.txt.Witec("fileio/txt.Witec/Witec-Map_no.txt",
#    type = "map", hdr.label = FALSE, hdr.units = FALSE,
#    points.per.line = 5, lines.per.image = 5
#  )

## ----witec-txt-Graph, results='hide'--------------------------------------------------------------
#  read.txt.Witec.Graph("fileio/txt.Witec/Witec-timeseries (Header).txt")
#  read.txt.Witec.Graph("fileio/txt.Witec/Witec-Map (Header).txt", type = "map")
#  read.txt.Witec.Graph("fileio/txt.Witec/nofilename (Header).txt", encoding = "latin1")

## ----comment="", eval=TRUE, echo=FALSE, class.output="add-border sourceCode r"--------------------
writeLines(readLines("read.txt.PerkinElmer.R"))

## ----read.txt.PerkinElmer, message=FALSE----------------------------------------------------------
#  source("read.txt.PerkinElmer.R")
#  read.txt.PerkinElmer(Sys.glob("fileio/txt.PerkinElmer/flu?.txt"), skip = 54)

## ----comment="", eval=TRUE, echo=FALSE, class.output="add-border sourceCode r"--------------------
writeLines(readLines("read.ENVI.Nicolet.R"))

## ----read-fileformats-data, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------
# ----------------------------------------------------------------------------
options(knitr.kable.NA = "")
# ----------------------------------------------------------------------------
fileformats <- read.table("fileio--fileformats.txt", header = TRUE, sep = "|",
  strip.white = TRUE, na.strings = "")

fileformats$html_unfriendly_link <- NULL

fileformats$Function <-
  ifelse(
    is.na(fileformats$Function),
    "",
    paste0("`", fileformats$Function, "()`{.r}")
  )

fileformats$Link <- ifelse(
  is.na(fileformats$Link),
  "",
  paste0("\\@ref(sec:", fileformats$Link, ")")
)

rownames(fileformats) <- NULL

## ----by-format, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------------------
kbl1 <- knitr::kable(
  fileformats[order(fileformats$Format)[!is.na(fileformats$Format)], ],
  format = "html",
  row.names = FALSE
  # , caption = "File Import Functions by Format.  "
)

kableExtra::pack_rows(kbl1, index = table(fileformats$Format))

## ----by-manufacturer, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------------
kbl2 <- knitr::kable(
  fileformats[order(fileformats$Manufacturer), ],
  format = "html",
  row.names = FALSE
  # , caption = "File Import Functions by Manufacturer.  "
)

kableExtra::pack_rows(kbl2, index = table(fileformats$Manufacturer))

## ----by-spectroscopy, paged.print=FALSE, echo=FALSE, eval=TRUE------------------------------------
kbl <- knitr::kable(
  fileformats[order(fileformats$Spectroscopy), ],
  format = "html",
  row.names = FALSE
  # , caption = "File Import Functions by Spectroscopy.  "
)

kableExtra::pack_rows(kbl, index = table(fileformats$Spectroscopy))

## ----session-info-fileio, paged.print=FALSE, eval=TRUE--------------------------------------------
sessioninfo::session_info()

