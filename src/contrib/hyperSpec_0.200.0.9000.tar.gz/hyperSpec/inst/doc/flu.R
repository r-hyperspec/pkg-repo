## ----cleanup-flu, include = FALSE-----------------------------------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporaty options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes <- getOption("show_reviewers_notes", TRUE)

## ----bib, echo=FALSE, paged.print=FALSE-----------------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c(
    "hyperSpec"
  ),
  file = "resources/flu-pkg.bib"
)

## ----echo=FALSE-----------------------------------------------------------------------------------
# From "read.txt.PerkinElmer.R"
read.txt.PerkinElmer <- function(files = stop("filenames needed"), ..., label = list()) {
  ##  set default labels
  label <- modifyList(
    list(
      .wavelength = expression(lambda / nm),
      spc = expression(I[fl] / "a.u.")
    ),
    label
  )

  if (length(files) == 0) {
    warning("No files found.")
    return(new("hyperSpec"))
  }

  ## read the first file
  buffer <- matrix(scan(files[1], ...), ncol = 2, byrow = TRUE)

  ## first column gives the wavelength vector
  wavelength <- buffer[, 1]

  ## preallocate the spectra matrix:
  ##  one row per file x as many columns as the first file has
  spc <- matrix(ncol = nrow(buffer), nrow = length(files))

  ## the first file's data goes into the first row
  spc[1, ] <- buffer[, 2]

  ## now read the remaining files
  for (f in seq(along = files)[-1]) {
    buffer <- matrix(scan(files[f], ...), ncol = 2, byrow = TRUE)

    ## check whether they have the same wavelength axis
    if (!all.equal(buffer[, 1], wavelength)) {
      stop(paste(files[f], "has different wavelength axis."))
    }

    spc[f, ] <- buffer[, 2]
  }

  ## make the hyperSpec object
  spc <- new("hyperSpec", wavelength = wavelength, spc = spc, label = label)

  ## consistent file import behaviour across import functions
  hyperSpec::.spc_io_postprocess_optional(spc, files)
}

## ----read.txt.PE----------------------------------------------------------------------------------
source("read.txt.PerkinElmer.R")

folder <- system.file("extdata/flu", package = "hyperSpec")
files  <- Sys.glob(paste0(folder, "/flu?.txt"))
flu    <- read.txt.PerkinElmer(files, skip = 54)

## ----rawspc---------------------------------------------------------------------------------------
flu

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Six spectra of `flu` dataset.  "

## ----rawfig, fig.cap=CAPTION----------------------------------------------------------------------
plot(flu)

## ----newdata--------------------------------------------------------------------------------------
flu$c <- seq(from = 0.05, to = 0.30, by = 0.05)
labels(flu, "c") <- "c, mg/l"

flu

## ----eval=FALSE-----------------------------------------------------------------------------------
#  save(flu, file = "flu.rda")

## ----newc-----------------------------------------------------------------------------------------
flu$c

## -------------------------------------------------------------------------------------------------
flu$..

## ----delcol---------------------------------------------------------------------------------------
flu$filename <- NULL

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Spectra intensities at 450 nm. "

## ----calplot1, fig.cap=CAPTION--------------------------------------------------------------------
plot_c(flu[, , 450])

## ----cutspc---------------------------------------------------------------------------------------
flu <- flu[, , 450]
labels(flu, "spc") <- expression(I["450 nm"] / a.u.)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Spectra intensities at 450 nm with updated labels. "

## ----calplot2, fig.cap=CAPTION--------------------------------------------------------------------
plot_c(flu, xlim = range(0, flu$c), ylim = range(0, flu$spc))

## ----abbrev-1-------------------------------------------------------------------------------------
flu[[]]

## ----abbrev-2, paged.print=FALSE------------------------------------------------------------------
flu$.

## ----abbrev-3-------------------------------------------------------------------------------------
flu$..

## ----cal------------------------------------------------------------------------------------------
calibration <- lm(c ~ spc, data = flu$.)

## ----summarymodel---------------------------------------------------------------------------------
summary(calibration)

## ----pred-----------------------------------------------------------------------------------------
I <- c(125, 400)
conc <- predict(calibration,
  newdata = list(spc = as.matrix(I)), interval = "prediction",
  level = .99
)
conc

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "Calibration function and its 99% confidence interval.  "

## ----calplot3, fig.cap=CAPTION--------------------------------------------------------------------
int <- list(spc = as.matrix(seq(min(flu), max(flu), length.out = 25)))
ci <- predict(calibration, newdata = int, interval = "confidence", level = 0.99)

panel.ci <- function(x, y, ..., intensity, ci.lwr, ci.upr, ci.col = "#606060") {
  panel.xyplot(x, y, ...)
  panel.lmline(x, y, ...)
  panel.lines(ci.lwr, intensity, col = ci.col)
  panel.lines(ci.upr, intensity, col = ci.col)
}

plot_c(flu,
  panel = panel.ci,
  intensity = int$spc, ci.lwr = ci[, 2], ci.upr = ci[, 3]
)

## ----calplot4.1-----------------------------------------------------------------------------------
flu$type <- "data points"

## ----calplot4.2-----------------------------------------------------------------------------------
tmp <- new("hyperSpec",
  spc = as.matrix(seq(min(flu), max(flu), length.out = 25)),
  wavelength = 450
)
ci <- predict(calibration, newdata = tmp$., interval = "confidence", level = 0.99)
tmp <- tmp[rep(seq(tmp, index = TRUE), 3)]
tmp$c <- as.numeric(ci)
tmp$type <- rep(colnames(ci), each = 25)

flu <- collapse(flu, tmp)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "calibration function and its 99% confidence interval and predicted points. "

## ----calplot4, fig.cap=CAPTION--------------------------------------------------------------------
panel.predict <-
  function(x, y, ..., intensity, ci, pred.col = "red", pred.pch = 19, pred.cex = 1) {

    panel.xyplot(x, y, ...)
    mapply(function(i, lwr, upr, ...) {
      panel.lines(c(lwr, upr), rep(i, 2), ...)
    },
    intensity, ci[, 2], ci[, 3],
    MoreArgs = list(col = pred.col)
    )
    panel.xyplot(ci[, 1], intensity, col = pred.col, pch = pred.pch, cex = pred.cex, type = "p")
  }

plot_c(flu,
  groups = type, type = c("l", "p"),
  col = c("black", "black", "#606060", "#606060"),
  pch = c(19, NA, NA, NA),
  cex = 0.5,
  lty = c(0, 1, 1, 1),
  panel = panel.predict,
  intensity = I,
  ci = conc,
  pred.cex = 0.5
)

## ----session-info-flu, paged.print=FALSE----------------------------------------------------------
sessioninfo::session_info("hyperSpec")

