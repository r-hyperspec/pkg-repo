## ----cleanup-hyperspec, include = FALSE-----------------------------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)
library(mvtnorm)
library(pls)
library(colorspace)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporary options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes = getOption("show_reviewers_notes", TRUE)

## ----bib, echo = FALSE, paged.print = FALSE-------------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c("hyperSpec",
    "baseline",
    "matrixStats",
    "mvtnorm",
    "plotrix",
    "pls"
  ),
  file = "resources/intro-pkg.bib",
  prefix = "R-"
)

## ---- echo = FALSE, results = "asis"--------------------------------------------------------------
res <- knitr::knit_child("list-of-vignettes.md", quiet = TRUE)
cat(res, sep = '\n')

## ----structure, echo = FALSE, fig.cap = CAPTION, out.width = "600"--------------------------------
knitr::include_graphics("intro--structure--hyperSpec--objects.png")
CAPTION = "The structure of the data in a `hyperSpec` object.  In this example the 'extra data' are the `x`, `y` and `c` columns in `@data`."

## ----print----------------------------------------------------------------------------------------
faux_cell

## ----nwl------------------------------------------------------------------------------------------
nrow(faux_cell)

## ----nwl2-----------------------------------------------------------------------------------------
nwl(faux_cell)

## ----nwl3-----------------------------------------------------------------------------------------
ncol(faux_cell)

## ----nwl4-----------------------------------------------------------------------------------------
dim(faux_cell)

## ----names----------------------------------------------------------------------------------------
colnames(faux_cell)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "An example with `[]` operator and positive indices.  "

## ----selspc, fig.cap = CAPTION--------------------------------------------------------------------
data(palette_colorblind) # load colorblind-friendly palette
plot(flu, col = palette_colorblind[4])
plot(flu[1:3], add = TRUE)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "An example with `[]` operator and negative indices.  "

## ----delspc, fig.cap = CAPTION--------------------------------------------------------------------
plot(flu, col = palette_colorblind[4])
plot(flu[-3], add = TRUE)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "An example with `[]` operator and logical indices.  "

## ----selspc2, fig.cap = CAPTION-------------------------------------------------------------------
plot(flu, col = palette_colorblind[4])
plot(flu[flu$c > 0.2], add = TRUE)

## ----sample---------------------------------------------------------------------------------------
sample(faux_cell, 3)

## ----isample--------------------------------------------------------------------------------------
sample(faux_cell, 3, index = TRUE)

## ----seq------------------------------------------------------------------------------------------
seq(faux_cell, length.out = 3, index = TRUE)
seq(faux_cell, by = 100)

## ----data-----------------------------------------------------------------------------------------
colnames(faux_cell)

## ----data-faux-cell-b-----------------------------------------------------------------------------
faux_cell[[1:3, 1]]

## ----data-faux-cell-c-----------------------------------------------------------------------------
faux_cell[[1:3, -5]]

## ----data-faux-cell-d-----------------------------------------------------------------------------
faux_cell[[1:3, "x"]]

## ----data-faux-cell-e-----------------------------------------------------------------------------
faux_cell[[1:3, c(FALSE, TRUE)]] # note the recycling!

## ----data2----------------------------------------------------------------------------------------
flu$c

## ----data3----------------------------------------------------------------------------------------
flu$n <- list(1:6, label = "sample no.")

## ----data4----------------------------------------------------------------------------------------
indexmatrix <- matrix(c(1:3, 1:3), ncol = 2)
indexmatrix

## ----data4b---------------------------------------------------------------------------------------
faux_cell[[indexmatrix, wl.index = TRUE]]

## ----data4c---------------------------------------------------------------------------------------
diag(faux_cell[[1:3, , min ~ min + 2i]])

## ----wl2ivec--------------------------------------------------------------------------------------
wl2i(flu, 405:410)

## ----wl2ivec2-------------------------------------------------------------------------------------
wl2i(flu, 405 ~ 410)

## ----wl2ivec3-------------------------------------------------------------------------------------
wl2i(faux_cell, 1000:1010)

## ----wl2ivec4-------------------------------------------------------------------------------------
wl2i(faux_cell, 1000 ~ 1010)

## ----wl2i.minmax----------------------------------------------------------------------------------
wl2i(flu, min ~ 410)

## ----wl2i.im--------------------------------------------------------------------------------------
wl2i(flu, 450 - 2i ~ 450 + 2i)
wl2i(flu, max - 2i ~ max)

## ----wl2i.list------------------------------------------------------------------------------------
wl2i(flu, c(min ~ 406.5, max - 2i ~ max))

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Spectra of `paracetamol` in range of 2800--3200 cm^-1^."

## ----paracetamol, fig.cap = CAPTION---------------------------------------------------------------
plot(paracetamol[, , 2800 ~ 3200])

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Spectra of `paracetamol`: from 2800^th^ to 3200^th^ point on *wavelength* axis.  "

## ----fig.cap = CAPTION----------------------------------------------------------------------------
plot(paracetamol[, , 2800:3200, wl.index = TRUE])

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Spectra of `paracetamol` with 500^th^ to 1000^th^ *wavelength* axis point removed.  "

## ----fig.cap = CAPTION----------------------------------------------------------------------------
plot(paracetamol[, , -(500:1000), wl.index = TRUE])

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Spectra of `paracetamol` with range from 1750 to 2800 cm^-1^ removed.  "

## ----fig.cap = CAPTION----------------------------------------------------------------------------
plot(paracetamol[, , c(min ~ 1750, 2800 ~ max)])

## ----laser----------------------------------------------------------------------------------------
laser

## ----merged---------------------------------------------------------------------------------------
wavelengths <- wl(laser)
frequencies <- 2.998e8 / wavelengths / 1000
wl(laser) <- frequencies
labels(laser, ".wavelength") <- "f / THz"
laser
rm(laser)

## -------------------------------------------------------------------------------------------------
wl(laser, "f / THz") <- frequencies

## -------------------------------------------------------------------------------------------------
wl(laser) <- list(wl = frequencies, label = "f / THz")

## ----wl_sort--------------------------------------------------------------------------------------
barb <- collapse(barbiturates[1:3])
wl(barb)

## ----wl_sort-2------------------------------------------------------------------------------------
barb <- wl_sort(barb)
wl(barb)

## -------------------------------------------------------------------------------------------------
flu <- flu[, , 400 ~ 407] # make a small and handy version of the flu data set
as.data.frame(flu)

## -------------------------------------------------------------------------------------------------
colnames(as.data.frame(flu))

## -------------------------------------------------------------------------------------------------
as.data.frame(flu)$spc

## -------------------------------------------------------------------------------------------------
flu$.

## -------------------------------------------------------------------------------------------------
flu$..

## -------------------------------------------------------------------------------------------------
flu[[, c("c", "spc")]]

## -------------------------------------------------------------------------------------------------
as.t.df(apply(flu, 2, mean_pm_sd))

## -------------------------------------------------------------------------------------------------
head(as.long.df(flu), 20)

## -------------------------------------------------------------------------------------------------
flu[[]]

## -------------------------------------------------------------------------------------------------
class(flu[[]])

## -------------------------------------------------------------------------------------------------
flu[[1:3, , 406 ~ 407]]

## -------------------------------------------------------------------------------------------------
flu[[1:3, c("filename", "spc"), 406 ~ 407]]

## ----eval = FALSE---------------------------------------------------------------------------------
#  spc <- new("hyperSpec", spc = spectra.matrix, wavelength = wavelength.vector, data = extra.data)

## -------------------------------------------------------------------------------------------------
pcov <- cov_pooled(faux_cell, faux_cell$region)
rnd  <- rmmvnorm(rep(10, 3), mean = pcov$mean, sigma = pcov$COV)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Multivariate normally distributed random spectra generated with `rmmvnorm()`{.r}."

## ----sim-spc, fig.cap = CAPTION-------------------------------------------------------------------
cluster.cols <- palette_colorblind[c(2, 7, 4)]
plot(rnd, col = cluster.cols[rnd$.group])

## -------------------------------------------------------------------------------------------------
tmp <- faux_cell
wl(tmp) <- wl(tmp) - 10

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <-
"Shifting the spectra along the wavelength axis: changing the wavelength values.  "

## ----shift-wl, fig.cap = CAPTION------------------------------------------------------------------
plot(faux_cell[135])
plot(tmp[135, , ], add = TRUE, col = palette_colorblind[4])

## ----fun-interpolate------------------------------------------------------------------------------
interpolate <- function(spc, shift, wl) {
  spline(wl + shift, spc, xout = wl, method = "natural")$y
}

## -------------------------------------------------------------------------------------------------
tmp <- apply(faux_cell, 1, interpolate, shift = -10, wl = wl(faux_cell))

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Shifting the spectra along the wavelength axis: interpolation.  "

## ----shift-interp, fig.cap = CAPTION, results = "hide"--------------------------------------------
plot(faux_cell[135])
plot(tmp[135], add = TRUE, col = palette_colorblind[4])

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Shifting the spectra along the wavelength axis.
Detail view of the phenylalanine band: shifting by `wl<-`{.r} (red) does not affect the intensities, while the spectrum is slightly changed by interpolations (blue).  "

## ----shift-untsch, fig.cap = CAPTION, results = "hide"--------------------------------------------
tmp <- faux_cell[135, , 990 ~ 1010]
plot(tmp, lines.args = list(type = "b", pch = 19, cex = 0.5))
wl(tmp) <- wl(tmp) - 0.5
plot(tmp, lines.args = list(type = "b", pch = 19, cex = 0.5), add = TRUE, col = palette_colorblind[4])

tmp <- faux_cell[135]
tmp <- apply(tmp, 1, function(x, wl, shift) {
  spline(wl + shift, x, xout = wl)$y
},
  wl = wl(tmp), shift = -0.5
)
plot(tmp, lines.args = list(type = "b", pch = 19, cex = 0.5), add = TRUE, col = palette_colorblind[3])

## -------------------------------------------------------------------------------------------------
shifts <- rnorm(nrow(faux_cell))
tmp <- faux_cell[[]]
for (i in seq_len(nrow(faux_cell))) {
  tmp[i, ] <- interpolate(tmp[i, ], shifts[i], wl = wl(faux_cell))
}
faux_cell[[]] <- tmp

## ----include = FALSE------------------------------------------------------------------------------
# FIXME: remove when the bug is solved
tmp_false <- FALSE

## ----eval = tmp_false-----------------------------------------------------------------------------
#  # FIXME: this code currently does not work.
#  find_max <- function(y, x) {
#    pos <- which.max(y) + (-1:1)
#    X <- x[pos] - x[pos[2]]
#    Y <- y[pos] - y[pos[2]]
#  
#    X <- cbind(1, X, X^2)
#    coef <- qr.solve(X, Y)
#  
#    - coef[2] / coef[3] / 2 + x[pos[2]]
#  }
#  
#  bandpos <- apply(faux_cell[[, , 1190 ~ 1210]], 1, find_max, wl(faux_cell[, , 1190 ~ 1210]))
#  refpos <- find_max(colMeans(faux_cell[[, , 1190 ~ 1210]]),  wl(faux_cell[, , 1190 ~ 1210]))
#  
#  shift1 <- refpos - bandpos

## -------------------------------------------------------------------------------------------------
faux_cell_tmp <- faux_cell - spc_fit_poly_below(faux_cell[, , min + 3i ~ max - 3i], faux_cell)
faux_cell_tmp <- sweep(faux_cell_tmp, 1, rowMeans(faux_cell[[]], na.rm = TRUE), "/")

## -------------------------------------------------------------------------------------------------
targetfn <- function(shift, wl, spc, targetspc) {
  error <- spline(wl + shift, spc, xout = wl)$y - targetspc
  sum(error^2)
}

shift2 <- numeric(nrow(faux_cell))
tmp <- faux_cell[[]]
target <- colMeans(faux_cell[[]])
for (i in 1:nrow(faux_cell)) {
  shift2[i] <- unlist(optimize(targetfn,
    interval = c(-5, 5),
    wl = faux_cell@wavelength,
    spc = tmp[i, ], targetspc = target
  )$minimum)
}

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <-
  "The shifts used to disturb the `faux_cell` data (original), and the remaining shift after correction with the two methods discussed here.  "

## ----fit-shift, fig.cap = CAPTION, eval = tmp_false-----------------------------------------------
#  # FIXME: this code currently does not work.
#  df <- data.frame(
#    shift = c(shifts, shifts + shift1, shifts + shift2),
#    method = rep(c("original", "find maximum", "interpolation"),
#      each = nrow(faux_cell)
#    )
#  )
#  plot(histogram(~ shift | method,
#    data = df, breaks = do.breaks(range(df$shift), 25),
#    layout = c(3, 1)
#  ))

## ----eval = FALSE---------------------------------------------------------------------------------
#  ir_spc   <- faux_cell / 1500 ## fake IR data
#  high_int <- apply(ir_spc > 1, 1, any) # any point above 1 is bad
#  low_int  <- apply(ir_spc, 1, max) < 0.1 # the maximum should be at least 0.1
#  ir_spc   <- ir_spc[!high_int & !low_int]

## -------------------------------------------------------------------------------------------------
mean_sd_filter <- function(x, n = 5) {
  x <- x - mean(x)
  s <- n * sd(x)
  (x <= s) & (x > -s)
}

OK <- apply(faux_cell[[]], 2, mean_sd_filter, n = 4) # logical matrix

spc.OK <- faux_cell[apply(OK, 1, all)]

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Filtering data: mean $\\pm$ sd filter.  "

## ----filter, fig.cap = CAPTION--------------------------------------------------------------------
plot(faux_cell[!apply(OK, 1, all)])
i <- which(!OK, arr.ind = TRUE)
points(wl(faux_cell)[i[, 2]], faux_cell[[!OK]], pch = 19, col = palette_colorblind[4], cex = 0.5)

## -------------------------------------------------------------------------------------------------
spc <- faux_cell[1:3, , min ~ min + 15i]
spc[[cbind(1:3, sample(nwl(spc), 3)), wl.index = TRUE]] <- 0
spc[[]]

## -------------------------------------------------------------------------------------------------
spc[[spc < 1e-4]] <- NA
spc[[]]

## -------------------------------------------------------------------------------------------------
spc.corrected <- spc_na_approx(spc)
spc.corrected[[]]

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Filtering data: remove bad points.  "

## ----bad, fig.cap = CAPTION-----------------------------------------------------------------------
spc[[is.na(spc)]] <- 0
plot(spc)

spc[[spc < 1e-4]] <- NA
plot(spc_na_approx(spc), add = TRUE, col = palette_colorblind[4],
  lines.args = list(type = "b", pch = 19, cex = 0.5)
)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Smoothing interpolation by `spc_loess()`{.r} with new data point spacing of 2 cm^-1^ (red) and `spc_bin()`{.r} (blue).  "

## ----fig-loess, fig.cap = CAPTION-----------------------------------------------------------------
plot(paracetamol, wl.range = c(300 ~ 1800, 2800 ~ max), xoffset = 850)
p <- spc_loess(paracetamol, c(seq(300, 1800, 2), seq(2850, 3150, 2)))
plot(p, wl.range = c(300 ~ 1800, 2800 ~ max), xoffset = 850, col = palette_colorblind[4], add = TRUE)

b <- spc_bin(paracetamol, 4)
plot(b,
  wl.range = c(300 ~ 1800, 2800 ~ max), xoffset = 850,
  lines.args = list(pch = 20, cex = .3, type = "p"), col = palette_colorblind[3], add = TRUE
)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The magnification of Fig. \\@ref(fig:fig-loess) shows how interpolation may cause a loss in signal height.  "

## ----loess-kl, fig.cap = CAPTION------------------------------------------------------------------
plot(paracetamol[, , 1600 ~ 1670])
plot(p[, , 1600 ~ 1670], col = palette_colorblind[4], add = TRUE)
plot(b[, , 1600 ~ 1670], col = palette_colorblind[3], add = TRUE)

## ----eval = FALSE---------------------------------------------------------------------------------
#  sweep(spectra, 2, background.spectrum, "-")

## ----ofs------------------------------------------------------------------------------------------
offsets <- apply(faux_cell, 1, min)
faux_cell_offset_corrected <- sweep(faux_cell, 1, offsets, "-")

## ----ofs2-----------------------------------------------------------------------------------------
faux_cell_offset_corrected <- sweep(faux_cell, 1, min, "-")

## ----bl-------------------------------------------------------------------------------------------
bl <- spc_fit_poly_below(faux_cell)
faux_cell_tmp <- faux_cell - bl

## ----do-bl----------------------------------------------------------------------------------------
corrected <- hyperSpec::faux_cell[1] # start with the unchanged data set

library("baseline")
bl <- baseline(corrected[[]], method = "modpolyfit", degree = 4)
corrected[[]] <- getCorrected(bl)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The first spectrum of `faux_cell`{.r} (raw data) with baseline.  "

## ----bl-baseline, fig.cap = CAPTION---------------------------------------------------------------
baseline <- corrected
baseline[[]] <- getBaseline(bl)
plot(hyperSpec::faux_cell[1], plot.args = list(ylim = range(hyperSpec::faux_cell[1], 0)))
plot(baseline, add = TRUE, col = palette_colorblind[4])

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- 'Baseline correction using the **baseline** package:
the first spectrum of `faux_cell`{.r}  after baseline correction with method "odpolyfi".  '

## ----bl-baseline-2, fig.cap = CAPTION-------------------------------------------------------------
plot(corrected, plot.args = list(ylim = range(hyperSpec::faux_cell[1], 0)))

## -------------------------------------------------------------------------------------------------
rm(bl, faux_cell)

## ----eval = FALSE---------------------------------------------------------------------------------
#  sweep(spectra, 2, offset.spectrum, "-")

## ----eval = FALSE---------------------------------------------------------------------------------
#  sweep(spectra, 2, photon.efficiency, "/")

## ----eval = FALSE---------------------------------------------------------------------------------
#  sweep(spectra, SPC, pixel.offsets, "-")

## ----eval = FALSE---------------------------------------------------------------------------------
#  sweep(spectra, SPC, illumination.factors, "*")

## ----normalize1-----------------------------------------------------------------------------------
faux_cell_tmp <- sweep(faux_cell, 1, mean, "/")

## ----eval = FALSE---------------------------------------------------------------------------------
#  normalized <- sweep (spectra, 1, factors, "*")

## ----norm-----------------------------------------------------------------------------------------
factors <- 1 / apply(faux_cell[, , 1600 ~ 1700], 1, mean)
faux_cell_tmp <- sweep(faux_cell, 1, factors, "*")

## ----norm-rowmeans--------------------------------------------------------------------------------
factors <- 1 / rowMeans(faux_cell[, , 1600 ~ 1700])

## ----norm-2---------------------------------------------------------------------------------------
faux_cell_tmp <- faux_cell * factors

## ----areanorm-shortcut----------------------------------------------------------------------------
faux_cell_tmp <- faux_cell / rowMeans(faux_cell[, , 1600 ~ 1700])

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "Mean-centered spectra of `flu`.  "

## ----centre-flu, fig.cap = CAPTION----------------------------------------------------------------
flu.centered <- scale(flu, scale = FALSE)
plot(flu.centered)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The summary spectra of `faux_cell` with 5^th^ percentile subtracted.  "

## ----perc, fig.cap = CAPTION, include=TRUE--------------------------------------------------------
faux_cell_tmp <- scale(faux_cell, center = quantile(faux_cell, 0.05), scale = FALSE)
plot(faux_cell_tmp, "spcprctl5")

## ----msc, eval = FALSE----------------------------------------------------------------------------
#  library(pls)
#  faux_cell_msc <- faux_cell
#  faux_cell_msc[[]] <- msc(faux_cell[[]])

## ----eval = FALSE---------------------------------------------------------------------------------
#  absorbance.spectra = - log10 (transmission.spectra)

## ----label, eval = FALSE--------------------------------------------------------------------------
#  labels(absorbance.spectra)$spc <- "A"

## ----pca------------------------------------------------------------------------------------------
pca <- prcomp(~spc, data = faux_cell$., center = FALSE)

## ----pca-auto-------------------------------------------------------------------------------------
pca <- prcomp(~spc, data = faux_cell, center = FALSE)

## ----decomp---------------------------------------------------------------------------------------
scores <- decomposition(faux_cell, pca$x,
  label.wavelength = "PC",
  label.spc = "score / a.u."
)
scores

## ----loadings-------------------------------------------------------------------------------------
loadings <- decomposition(faux_cell, t(pca$rotation),
  scores = FALSE,
  label.spc = "loading I / a.u."
)
loadings

## ----retain.col-----------------------------------------------------------------------------------
loadings <- decomposition(faux_cell, t(pca$rotation),
  scores = FALSE,
  retain.columns = TRUE, label.spc = "loading I / a.u."
)
loadings[1]$..

## ----retain---------------------------------------------------------------------------------------
faux_cell$measurement <- 1
loadings <- decomposition(faux_cell, t(pca$rotation),
  scores = FALSE,
  label.spc = "loading I / a.u."
)
loadings[1]$..

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The first three loadings.  "

## ----pca-load, fig.cap = CAPTION------------------------------------------------------------------
plot(loadings[1:3], stacked = TRUE)

## ----div_palette----------------------------------------------------------------------------------
div_palette <- colorRampPalette(c(
  "#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5",
  "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2",
  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
  "#A9432F", "#9A2919", "#8B0000"
), space = "Lab")

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The third score map.  "

## ----pca-score, fig.cap = CAPTION, sq.fig = TRUE--------------------------------------------------
plot_map(scores[, , 3], col.regions = diverging_hcl(20, palette = "Blue-Red2"))

## ----pca-smooth-----------------------------------------------------------------------------------
smoothed <- scores[, , 1:10] %*% loadings[1:10]

## ----hca------------------------------------------------------------------------------------------
dist <- dist_pearson(faux_cell[[]])

## ----hca-asmatrix---------------------------------------------------------------------------------
dist <- dist_pearson(faux_cell)
dendrogram <- hclust(dist, method = "ward.D")

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The results of the cluster analysis: the dendrogram.  "

## ----dend, fig.cap = CAPTION, sq.fig = TRUE-------------------------------------------------------
plot(dendrogram, labels = FALSE, hang = -1)

## ----dendcut--------------------------------------------------------------------------------------
faux_cell$region <- as.factor(cutree(dendrogram, k = 3))

## ----clustname------------------------------------------------------------------------------------
levels(faux_cell$region) <- c("matrix", "lacuna", "cell")

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The results of the cluster analysis: the map of the 3 clusters.  "

## ----clust-map, fig.cap = CAPTION, sq.fig = TRUE--------------------------------------------------
plot_map(faux_cell, region ~ x * y, col.regions = cluster.cols)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The results of the cluster analysis: the the mean spectra.  "

## ----clustmean, fig.cap = CAPTION-----------------------------------------------------------------
means <- aggregate(faux_cell, by = faux_cell$region, mean_pm_sd)
plot(means, col = cluster.cols, stacked = ".aggregate", fill = ".aggregate")

## ----cbind----------------------------------------------------------------------------------------
dim(flu)

## -------------------------------------------------------------------------------------------------
dim(cbind(flu, flu))

## -------------------------------------------------------------------------------------------------
dim(rbind(flu, flu))

## ----collapse-------------------------------------------------------------------------------------
barb <- collapse(barbiturates)
wl(barb)[1:25]

## ----collapse-wl-sort-----------------------------------------------------------------------------
barb <- wl_sort(barb)
barb[[1:3, , min ~ min + 10i]]

## ----merge-sample---------------------------------------------------------------------------------
faux_cell_low <- sample(faux_cell[, , min ~ 1200], 700)
nrow(faux_cell_low)

## ----merge-sample-2-------------------------------------------------------------------------------
faux_cell_high <- sample(faux_cell[, , 1400 ~ max], 700)
nrow(faux_cell_high)

## ----merge----------------------------------------------------------------------------------------
faux_cell_merged <- merge(faux_cell_low, faux_cell_high)
nrow(faux_cell_merged)

## -------------------------------------------------------------------------------------------------
faux_cell_merged <- merge(faux_cell_low, faux_cell_high, all = TRUE)
nrow(faux_cell_merged)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "For both spectral ranges some spectra are missing. "

## ----merge-map, fig.cap = CAPTION-----------------------------------------------------------------
matcols <- sequential_hcl(20, palette = "viridis")
levelplot(spc ~ x * y | as.factor(paste(.wavelength, "  1/cm")),
  faux_cell_merged[, , c(1000, 1650)],
  aspect = "iso", col.regions = matcols
)

## ----include = FALSE------------------------------------------------------------------------------
CAPTION <- "The missing parts of the spectra are filled with `NA`{.r}.  "

## ----merge-mat, fig.cap = CAPTION, sq.fig = TRUE--------------------------------------------------
plot(faux_cell_merged[1:100], "mat", col = matcols)

## -------------------------------------------------------------------------------------------------
merged <- merge(faux_cell[1:7, , 610 ~ 620], faux_cell[5:10, , 615 ~ 625], all = TRUE)
merged$.

## ----approxfun------------------------------------------------------------------------------------
approxfun <- function(y, wl, new.wl) {
  approx(wl, y, new.wl,
    method = "constant",
    ties = function(x) mean(x, na.rm = TRUE)
  )$y
}

## -------------------------------------------------------------------------------------------------
merged <- apply(merged, 1, approxfun,
  wl = wl(merged),
  new.wl = unique(wl(merged)),
  new.wavelength = "new.wl"
)
merged$.

## -------------------------------------------------------------------------------------------------
flu.ref <- data.frame(
  filename = rep(flu$filename[1:2], each = 2),
  cref     = rep(flu$c[1:2], each = 2) + rnorm(4, sd = 0.01)
)
flu.ref

## -------------------------------------------------------------------------------------------------
flu.merged <- merge(flu, flu.ref)
flu.merged$..

## -------------------------------------------------------------------------------------------------
flu.merged <- merge(flu, flu.ref, all.x = TRUE)
flu.merged$..

## -------------------------------------------------------------------------------------------------
class(merge(flu, flu.ref))

## -------------------------------------------------------------------------------------------------
class(merge(flu.ref, flu))

## ----split----------------------------------------------------------------------------------------
clusters <- split(faux_cell, faux_cell$region)
clusters

## -------------------------------------------------------------------------------------------------
lacunae <- droplevels(faux_cell[faux_cell$region == "matrix" & !is.na(faux_cell$region)])
summary(lacunae$region)

## -------------------------------------------------------------------------------------------------
cells <- droplevels(faux_cell[faux_cell$region == "cell" & !is.na(faux_cell$region)])
summary(cells$region)

## -------------------------------------------------------------------------------------------------
summary(rbind(cells, lacunae)$region)

## -------------------------------------------------------------------------------------------------
summary(collapse(cells, lacunae)$region)

## ----droplevels-----------------------------------------------------------------------------------
tmp <- faux_cell[1:50]
table(tmp$region)

## ----droplevels-2---------------------------------------------------------------------------------
tmp <- droplevels(tmp)
table(tmp$region)

## ----checkCompleteOptionTable, echo = FALSE, results = "hide"-------------------------------------
stopifnot(all(names(hy_get_options(TRUE)) %in% c(
  "debuglevel", "gc", "file.remove.emptyspc",
  "file.keep.name", "tolerance", "wl.tolerance", "plot.spc.nmax", "ggplot.spc.nmax"
)))

## ----speed1---------------------------------------------------------------------------------------
tmp <- faux_cell[1:50]
shifts <- rnorm(nrow(tmp))
system.time({
  for (i in seq_len(nrow(tmp))) {
    tmp[[i]] <- interpolate(tmp[[i]], shifts[i], wl = wl(tmp))
  }
})

## ----speed3---------------------------------------------------------------------------------------
tmp <- faux_cell[1:50]
system.time({
  tmp.matrix <- tmp[[]]
  wl <- wl(tmp)
  for (i in seq_len(nrow(tmp))) {
    tmp.matrix[i, ] <- interpolate(tmp.matrix[i, ], shifts[i], wl = wl)
  }
  tmp[[]] <- tmp.matrix
})

## ----session-info-hyperspec, paged.print = FALSE--------------------------------------------------
sessioninfo::session_info("hyperSpec")

