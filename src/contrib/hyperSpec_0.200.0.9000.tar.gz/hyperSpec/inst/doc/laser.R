## ----cleanup-laser, include = FALSE---------------------------------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)
# library(rgl)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporaty options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes <- getOption("show_reviewers_notes", TRUE)

## ----bib, echo=FALSE, paged.print=FALSE-----------------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c(
    "hyperSpec",
    "rgl"
  ),
  file = "resources/laser-pkg.bib",
  prefix = "R-"
)

## -------------------------------------------------------------------------------------------------
library(hyperSpec)

## -------------------------------------------------------------------------------------------------
# Renishaw file
file  <- system.file("extdata/laser.txt.gz", package = "hyperSpec")
laser <- read.txt.Renishaw(file, data = "ts")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The raw laser emission spectra.  "

## ----rawspc, fig.cap=CAPTION----------------------------------------------------------------------
plot(laser, "spcprctl5")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The cut spectra laser emission spectra.   "

## ----cutspc, fig.cap=CAPTION----------------------------------------------------------------------
laser <- laser[, , -75 ~ 0]
plot(laser, "spcprctl5")

## ----wlspc1---------------------------------------------------------------------------------------
wl(laser) <- wl(laser) + 50

## ----wlcalc---------------------------------------------------------------------------------------
wl(laser) <- list(
  wl = 1e7 / (1 / 405e-7 - wl(laser)),
  label = expression(lambda / nm)
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The spectra with wavelength axis. "

## ----wlspc, fig.cap=CAPTION-----------------------------------------------------------------------
plot(laser, "spcprctl5")

## -------------------------------------------------------------------------------------------------
laser$filename <- NULL
laser

## ----locator, eval=FALSE--------------------------------------------------------------------------
#  wls <- locator()$x

## ----echo=FALSE, results='hide'-------------------------------------------------------------------
wls <- c(405.0063, 405.1121, 405.2885, 405.3591)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The spectral position of the bands in the laser emission time series. "

## ----markspc, fig.cap=CAPTION---------------------------------------------------------------------
plot(laser, "spcmeansd")

cols <- c("black", "blue", "red", "darkgreen")
abline(v = wls, col = cols)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The time series data.
The colors in this plot correspond to colors in fig. \\@ref(fig:ts).  "

## ----ts, fig.cap=CAPTION, fig.width=7-------------------------------------------------------------
plot_c(laser[, , wls], spc ~ t, groups = .wavelength, type = "b", cex = 0.3, col = cols)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The time series plots can also be conditioned on `$.wavelength`{.r}. "

## ----tsextra, fig.cap=CAPTION, fig.width=7--------------------------------------------------------
plot_c(laser[, , wls], spc ~ t | .wavelength, type = "b", cex = 0.3, col = "black")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The spectra matrix of the `laser`{.r} data set.
The ordinate of the plot may be the number of the spectrum accessed by `$.row`{.r} (here) or any other extra data column, as, e.g., `$t`{.r} in fig. \\@ref(fig:plotmatt).  "

## ----plotmatr, fig.cap=CAPTION--------------------------------------------------------------------
plot(laser, "mat", contour = TRUE, col = "#00000060")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION <- "The spectra matrix of the `laser`{.r} data set.
The ordinate of the plot may be any extra data column, here `$t`{.r}.  "

## ----plotmatt, fig.cap=CAPTION--------------------------------------------------------------------
levelplot(spc ~ .wavelength * t, laser, contour = TRUE, col = "#00000080")

## ----eval=FALSE-----------------------------------------------------------------------------------
#  library(rgl)

## ----rgl-plot, eval=FALSE-------------------------------------------------------------------------
#  laser   <- laser [, , 404.8 ~ 405.6] / 10000
#  laser$t <- laser$t / 3600
#  cols <- rep(matlab.palette(nrow(laser)), nwl(laser))
#  
#  surface3d(y = wl(laser), x = laser$t, z = laser$spc, col = cols)
#  surface3d(
#    y = wl(laser), x = laser$t, z = laser$spc + .1 * min(laser),
#    col = "black", alpha = .2, front = "lines", line_antialias = TRUE
#  )
#  
#  aspect3d(c(1, 1, 0.25))
#  
#  axes3d(c("x+-", "y--", "z--"))
#  axes3d("y--", nticks = 25, labels = FALSE)
#  mtext3d("t / h", "x+-", line = 2.5)
#  mtext3d("lambda / nm", "y--", line = 2.5)
#  mtext3d("I / a.u.", "z--", line = 2.5)

## ----rgl-do, echo=show_reviewers_notes, eval=FALSE, results='hide'--------------------------------
#  # ============================================================================
#  # FIXME: is this code block still needed?
#  # Does not work correctly on my PC: results in white figure w/o spectra.
#  # ============================================================================
#  if (require(rgl)) {
#    open3d(windowRect = c(20, 20, 600, 350)) # this is needed only for automatically
#  
#    # producing the snapshot
#    par3d(
#      userMatrix = matrix(c(
#        -0.52, 0.4, -0.75, 0,
#        -0.85, -0.28, 0.44, 0,
#        -0.04, 0.87, 0.49, 0,
#        -0.75, 0.75, 0, 1
#      ), ncol = 4L),
#      scale = c(2.75, 5, 0.175),
#      windowRect = c(20L, 50L, 520L, 330L),
#      zoom = 0.75
#    )
#    rgl.snapshot("fig-3D.png", fmt = "png", top = TRUE)
#    rgl.quit()
#  } else {
#    png("laser--fig-3D.png")
#    ploterrormsg("", "rgl")
#    dev.off()
#  }

## ----laser3d, echo=FALSE, fig.cap=CAPTION, out.width="400"----------------------------------------
CAPTION <- "The 3d plot of the laser data.  "
knitr::include_graphics("laser--rgl-3d.png")

## ----session-info-laser, paged.print = FALSE------------------------------------------------------
sessioninfo::session_info("hyperSpec")

