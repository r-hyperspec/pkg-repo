## ----cleanup-plotting, include = FALSE------------------------------------------------------------
# Clean up to ensure reproducible workspace ----------------------------------
rm(list = ls(all.names = TRUE))

## ----setup, include = FALSE-----------------------------------------------------------------------
# Packages -------------------------------------------------------------------
library(hyperSpec)
library(latticeExtra)
library(ggplot2)
# library(rgl)

# Functions ------------------------------------------------------------------
source("vignette-functions.R", encoding = "UTF-8")

# Settings -------------------------------------------------------------------
source("vignette-default-settings.R", encoding = "UTF-8")

# Temporaty options ----------------------------------------------------------
# Change the value of this option in "vignette-default-settings.R"
show_reviewers_notes = getOption("show_reviewers_notes", TRUE)

## ----bib, echo=FALSE, paged.print=FALSE-----------------------------------------------------------
dir.create("resources", showWarnings = FALSE)

knitr::write_bib(
  c(
    "hyperSpec",
    "lattice",
    "latticeExtra",
    "rgl",
    "ggplot2",
    "plotrix"
  ),
  file = "resources/plotting-pkg.bib",
  prefix = "R-"
)

## ----check-required, echo=FALSE, results='tex', eval=FALSE----------------------------------------
#  msg <- function(...) system(sprintf("echo '%s'", paste(...)))
#  
#  required.pkgs <- c("latticeExtra", "rgl", "ggplot2")
#  
#  dummies <- check.req.pkg("latticeExtra",
#    griderrors = "panel.levelplot.points",
#    hynsgrid   = "plotvoronoi"
#  )
#  for (i in seq_along(dummies)) {
#    eval(dummies[[i]])
#  }
#  
#  for (p in required.pkgs [!required.pkgs %in% c("latticeExtra")]) {
#    check.req.pkg(p, donothing = "")
#  }

## ----packages-------------------------------------------------------------------------------------
library(hyperSpec)
library(latticeExtra)
library(ggplot2)
# library(rgl)

par(mar = c(4.1, 4.1, 1, .6))

set.seed(2020)

## ----preproc-faux-cell----------------------------------------------------------------------------
set.seed(1)
faux_cell <- generate_faux_cell()

faux_cell_preproc <- faux_cell - spc_fit_poly_below(faux_cell)
faux_cell_preproc <- faux_cell_preproc / rowMeans(faux_cell)
faux_cell_preproc <- faux_cell_preproc - quantile(faux_cell_preproc, 0.05)

cluster_cols   <- c("dark blue", "orange", "#C02020")
cluster_meansd <- aggregate(faux_cell_preproc, faux_cell$region, mean_pm_sd)
cluster_means  <- aggregate(faux_cell_preproc, faux_cell$region, mean)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra in dataset `flu`.  "

## ----plot-spc, fig.cap=CAPTION--------------------------------------------------------------------
plot_spc(flu)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Matrix of spectra: the colour coded intensities over the wavelengths and the row number.  "

## ----plotmat-flu, fig.cap=CAPTION-----------------------------------------------------------------
plotmat(flu)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Calibration plot: an intensity over concentration.  "

## ----plotflu, fig.cap=CAPTION---------------------------------------------------------------------
plotc(flu)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False colour map (1).  "

## ----levelplot-1, fig.cap=CAPTION-----------------------------------------------------------------
levelplot(spc ~ x * y, faux_cell[ , , 1200], aspect = "iso")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False colour map created with `plotmap()`{.r}.  "

## ----plotmap, fig.cap=CAPTION---------------------------------------------------------------------
plotmap(faux_cell[ , , 1200])

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Voronoi diagram: an example with `faux_cell` dataset.  "

## ----voronoi, fig.cap=CAPTION---------------------------------------------------------------------
plotvoronoi(sample(faux_cell, 300), region ~ x * y)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "All spectra of dataset `flu`.  "

## ----plot-spcflu, fig.cap=CAPTION-----------------------------------------------------------------
plot(flu, "spc")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Summary spectra: mean $\\pm$ one standard deviation at each wavelength (wavenumber).  "

## ----plotchomean, fig.cap=CAPTION-----------------------------------------------------------------
plot(faux_cell_preproc, "spcmeansd")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Summary spectra: median, 16^th^ and 84^th^ percentiles at each wavelength (wavenumber).  "

## ----plotchoprctl, fig.cap=CAPTION----------------------------------------------------------------
plot(faux_cell_preproc, "spcprctile")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Summary spectra: median, 5^th^, 16^th^, 84^th^, 95^th^ percentiles at each wavelength (wavenumber).  "

## ----plotchoprctl5, fig.cap=CAPTION---------------------------------------------------------------
plot(faux_cell_preproc, "spcprctl5")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Calibration plot: spectra intensities over concentration.  "

## ----plotflu2, fig.cap=CAPTION--------------------------------------------------------------------
plot(flu, "c")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Time series plot: spectra intensities over time.  "

## ----plotts, fig.cap=CAPTION----------------------------------------------------------------------
plot(laser[, , 405], "ts")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Depth profile plot.  "

## ----plotdepth, fig.cap=CAPTION-------------------------------------------------------------------
depth.profile <- new("hyperSpec",
  spc    = as.matrix(rnorm(20) + 1:20),
  data   = data.frame(z = 1:20),
  labels = list(
    spc = "I / a.u.",
    z   = expression(`/`(z, mu * m)),
    .wavelength = expression(lambda)
  )
)

plot(depth.profile, "depth")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra matrix.  "

## ----plotmat, fig.cap=CAPTION---------------------------------------------------------------------
plot(laser, "mat")

## ----eval=FALSE-----------------------------------------------------------------------------------
#  plotmat(laser)

## ----eval=FALSE-----------------------------------------------------------------------------------
#  levelplot(spc ~ .wavelength * .row, data = laser)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False color map: alternative R syntax.   "

## ----plotmapcho2, fig.cap=CAPTION-----------------------------------------------------------------
plot(faux_cell[ , , 1200], "map")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Voronoi plot: alternative R syntax.  "

## ----plotvoronoi, fig.cap=CAPTION-----------------------------------------------------------------
plot(sample(faux_cell[ , , 1200], 300), "voronoi")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Plot of wavelength (wavenumber) range from 700 to 1200 $cm^{-1}.$  "

## ----wavelength, fig.cap=CAPTION------------------------------------------------------------------
plot_spc(paracetamol[, , 700 ~ 1200])

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Plot of several wavelength (wavenumber) ranges.  "

## ----wavelength-2, fig.cap=CAPTION----------------------------------------------------------------
plot_spc(paracetamol,
  wl.range = c(300 ~ 1800, 2800 ~ max),
  xoffset = 750
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Plot with reversed/descending wavelength (wavenumber) range.  "

## ----abscissa, fig.cap=CAPTION--------------------------------------------------------------------
plot_spc(paracetamol, wl.reverse = TRUE)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra plotted in different colours.  "

## ----colours, fig.cap=CAPTION---------------------------------------------------------------------
plot_spc(flu, col = palette_matlab_dark(6))

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectrum with dots instead of lines.  "

## ----dots, fig.cap=CAPTION------------------------------------------------------------------------
plot_spc(paracetamol[, , 2800 ~ 3200],
  lines.args = list(pch = 20, type = "p")
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "An example of mass spectrum.  "

## ----mass, fig.cap=CAPTION------------------------------------------------------------------------
plot(barbiturates[[1]], lines.args = list(type = "h"))

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "A spectrum added to an existing plot.  "

## ----add, fig.cap=CAPTION-------------------------------------------------------------------------
plot_spc(faux_cell[30, , ])
plot_spc(faux_cell[35, , ], add = TRUE, col = "blue")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "A spectrum of summary statistics calculated via `func` parameter.
In the example, the standard deviation is used.  "

## ----sd, fig.cap=CAPTION--------------------------------------------------------------------------
plot_spc(faux_cell_preproc, func = sd)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectrum with added zero-intensity line.  "

## ----diffline, fig.cap=CAPTION--------------------------------------------------------------------
plot_spc(paracetamol,
  zeroline = list(col = "red")
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "A summary spectrum with annotation lines.  "

## ----add-line, fig.cap=CAPTION--------------------------------------------------------------------
plot(laser, "spcmeansd")
abline(
  v = c(405.0063, 405.1121, 405.2885, 405.3591),
  col = c("black", "blue", "red", "darkgreen")
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Stacked spectra of means.  "

## ----stacked1, fig.cap=CAPTION--------------------------------------------------------------------
plot_spc(
  cluster_means,
  col = cluster_cols,
  stacked = TRUE
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Stacked summary spectra (mean $\\pm$ one standard deviation).  "

## ----stacked2, fig.cap=CAPTION--------------------------------------------------------------------
op <- par(las = 1, mgp = c(3.1, .7, 0))

plot(
  cluster_meansd,
  stacked = ".aggregate",
  fill    = ".aggregate",
  col     = cluster_cols
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Stacked spectra with customized y offset.  "

## ----stacked3, fig.cap=CAPTION--------------------------------------------------------------------
plot_spc(
  cluster_meansd,
  yoffset = rep(0:2, each = 3),
  col = rep(cluster_cols, each = 3)
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Dense-stacked spectra.  "

## ----stacked4, fig.cap=CAPTION--------------------------------------------------------------------
yoffsets <- apply(cluster_means[[]], 2, diff)
yoffsets <- -apply(yoffsets, 1, min)
plot(cluster_means,
  yoffset = c(0, cumsum(yoffsets)),
  col = cluster_cols
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "An example of highly customized spectra.  "

## ----stacked5, fig.cap=CAPTION--------------------------------------------------------------------
yoffset <- apply(faux_cell_preproc, 2, quantile, c(0.05, 0.95))
yoffset <- range(yoffset)
plot(faux_cell_preproc[1],
  plot.args = list(ylim = c(0, 2) * yoffset),
  lines.args = list(type = "n")
)
yoffset <- (0:1) * diff(yoffset)
for (i in 1:3) {
  plot(faux_cell_preproc, "spcprctl5",
    yoffset = yoffset[i],
    col = "gray", add = TRUE
  )
  plot(faux_cell_preproc[i],
    yoffset = yoffset[i],
    col = palette_matlab_dark(3) [i], add = TRUE,
    lines.args = list(lwd = 2)
  )
}

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Intensities at 450 nm over concentration.  "

## ----lin-cal-1, fig.cap=CAPTION-------------------------------------------------------------------
plotc(flu[, , 450])

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "The summary (minimum and maximum) of intensities at each measured concentration.  "

## ----lin-cal-3, fig.cap=CAPTION-------------------------------------------------------------------
plotc(flu, func = range, groups = .wavelength)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Conditioning: several calibration spectra on separate subplots.  "

## ----plotc2, fig.cap=CAPTION----------------------------------------------------------------------
plotc(flu[, , c(405, 445)], spc ~ c | .wavelength,
  cex = .3, scales = list(alternating = c(1, 1))
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Grouping: several calibration spectra on one plot.  "

## ----plotc3, fig.cap=CAPTION----------------------------------------------------------------------
plotc(flu[, , c(405, 445)], groups = .wavelength)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Modified axis labels and point characters.  "

## ----lin-cal-4, fig.cap=CAPTION-------------------------------------------------------------------
plotc(flu[, , 450],
  ylab = expression(I["450 nm"] / a.u.),
  xlim = range(0, flu$c + .01),
  ylim = range(0, flu$spc + 10),
  pch = 4
)

## ----lincal-panel---------------------------------------------------------------------------------
panelcalibration <- function(x, y, ..., clim = range(x), level = .95) {
  panel.xyplot(x, y, ...)
  lm <- lm(y ~ x)
  panel.abline(coef(lm), ...)
  cx <- seq(clim[1], clim[2], length.out = 50)
  cy <- predict(lm, data.frame(x = cx),
    interval = "confidence",
    level = level
  )
  panel.lines(cx, cy[, 2], col = "gray")
  panel.lines(cx, cy[, 3], col = "gray")
}

## ----include=FALSE, fig.cap=CAPTION---------------------------------------------------------------
CAPTION = "Plot that uses a customized paanel function.  "

## ----lin-cal-5, fig.cap=CAPTION-------------------------------------------------------------------
plotc(flu[, , 405],
  panel = panelcalibration,
  pch = 4, clim = c(0, 0.35), level = .99
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Plot with abscissae explicitly indicated by model formula.  "

## ----plotc4, fig.cap=CAPTION----------------------------------------------------------------------
plotc(laser[, , c(405.0063, 405.1121, 405.2885, 405.3591)],
  spc ~ t,
  groups = .wavelength,
  type   = "b",
  col    = c("black", "blue", "red", "darkgreen")
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "An example of a levelplot.  "

## ----levelplot, fig.cap=CAPTION-------------------------------------------------------------------
levelplot(spc ~ x * y, data = faux_cell[ , , 800])

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Levelplot when colour-coded value is a factor.  "

## ----levelplot-factor, fig.cap=CAPTION------------------------------------------------------------
levelplot(region ~ x * y, data = faux_cell)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra matrix with non-default palette.  "

## ----plotmat1, fig.cap=CAPTION--------------------------------------------------------------------
plot(laser, "mat", col = heat.colors(20))

## ----plotmat1-a, eval=FALSE, fig.cap=CAPTION, eval=FALSE------------------------------------------
#  plotmat(laser, col = heat.colors(20))

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra matrix with time (in column `t`) on y axis.    "

## ----plotmat2, fig.cap=CAPTION--------------------------------------------------------------------
plotmat(laser, y = "t")

## ----eval=FALSE-----------------------------------------------------------------------------------
#  plotmat(laser, y = laser$t, ylab = labels(laser, "t"))

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Spectra matrix with added contour lines.  "

## ----plotmat3, fig.cap=CAPTION--------------------------------------------------------------------
plotmat(flu, col = palette_matlab_dark(20))
plotmat(flu, col = "white", contour = TRUE, add = TRUE)

## ----prep-plotmap-barb----------------------------------------------------------------------------
library("latticeExtra")

barb <- collapse(barbiturates)
barb <- wl_sort(barb)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Colour-coded points via special panel function.  "

## ----plotmap-barb, fig.cap=CAPTION----------------------------------------------------------------
levelplot(spc ~ .wavelength * z, barb,
  panel = panel.levelplot.points,
  cex = .33, col.symbol = NA,
  col.regions = palette_matlab
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "An example of a false colour map.  "

## ----plotmap-faux-cell, fig.cap=CAPTION-----------------------------------------------------------
plotmap(faux_cell[ , , 1200])

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False colour map with an explicit specification of x and y axes.  "

## ----plotmap-yx, fig.cap=CAPTION------------------------------------------------------------------
plotmap(faux_cell[ , , 1200], spc ~ y * x)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False colour map with colours defined by a factor variable.  "

## ----plotmap-clu, fig.cap=CAPTION-----------------------------------------------------------------
plotmap(faux_cell, region ~ x * y)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "False colour map with non-default colour palette.  "

## ----plotmap-col, fig.cap=CAPTION-----------------------------------------------------------------
plotmap(faux_cell, region ~ x * y, col.regions = cluster_cols)

## ----lattice-params-------------------------------------------------------------------------------
my_theme <- trellis.par.get()
names(my_theme) # note how many parameters are tunable

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "A false-colour map that uses `terrain.colors` palette.   "

## ----plotmap-col-default, fig.cap=CAPTION---------------------------------------------------------
my_theme$regions$col <- grDevices::terrain.colors
plotmap(faux_cell[ , , 1200], par.settings = my_theme)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Show **lattice** settings.  "

## ----lattice-settings-2, fig.width=7, fig.height=4, fig.cap=CAPTION, eval=FALSE-------------------
#  # Display current trellis parameters
#  show.settings()

## ----lattice-settings, fig.width=7, fig.height=4, fig.cap=CAPTION---------------------------------
show.settings(my_theme)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "A map of average intensity at explicitly indicated wavelengths.  "

## ----plotmap-wave, fig.cap=CAPTION----------------------------------------------------------------
plotmap(
  faux_cell_preproc[, , c(800, 1500)],
  col.regions = palette_matlab
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Subplots created by logical conditions.  "

## ----plotmap-pca, fig.cap=CAPTION-----------------------------------------------------------------
plotmap(
  faux_cell[ , , 1500],
  spc ~ y * x | x > 5,
  col.regions = palette_matlab(20)
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "The maps of the scores of the first two principal components (I).  "

## ----plotmap-pca2, fig.cap=CAPTION----------------------------------------------------------------
pca <- prcomp(~spc, data = faux_cell_preproc$.)

scores <- decomposition(faux_cell, pca$x,
  label.wavelength = "PC",
  label.spc = "score /  a.u."
)

plotmap(
  scores[, , 1:3],
  spc ~ y * x | as.factor(.wavelength),
  func = NULL,
  col.regions = palette_matlab(20)
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "The maps of the scores of the first two principal components (II).  "

## ----plotmap-pca3, fig.cap=CAPTION----------------------------------------------------------------
levelplot(
  spc ~ y * x | as.factor(.wavelength),
  scores[, , 1:3],
  aspect = "iso",
  col.regions = palette_matlab(20)
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Voronoi plot that uses non-default discrette colour palette.  "

## ----voronoi-2, fig.cap=CAPTION-------------------------------------------------------------------
plotvoronoi(
  sample(faux_cell, 300), region ~ x * y,
  col.regions = palette_matlab(20)
)

## -------------------------------------------------------------------------------------------------
mark.missing <- function(x, y, z, ...) {
  panel.levelplot(x, y, z, ...)

  miss <- expand.grid(x = unique(x), y = unique(y))
  miss <- merge(miss, data.frame(x, y, TRUE), all.x = TRUE)
  miss <- miss[is.na(miss[, 3]), ]
  panel.xyplot(miss[, 1], miss[, 2], pch = 4, ...)
}

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Marks of missing spectra in a false-colour map.  "

## ----missing, fig.cap=CAPTION---------------------------------------------------------------------
plotmap(sample(faux_cell[, , 1200], length(faux_cell) - 20),
  col.regions = palette_matlab(20),
  col = "black",
  panel = mark.missing
)

## ----uneven-prep----------------------------------------------------------------------------------
uneven <- faux_cell[, , 1200]
uneven$x <- uneven$x + round(rnorm(nrow(uneven), sd = 0.05), digits = 1)
uneven$y <- uneven$y + round(rnorm(nrow(uneven), sd = 0.05), digits = 1)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Unevenly spaced measurement grid: example I.
Note warnings `values are not equispaced; output may be wrong`."

## ----uneven-I, fig.cap=CAPTION--------------------------------------------------------------------
plotmap(uneven)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Unevenly spaced measurement grid: example II.  "

## ----uneven-II, fig.cap=CAPTION-------------------------------------------------------------------
plotvoronoi(uneven, backend = "deldir")

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Unevenly spaced measurement grid: example III.  "

## ----uneven-III, fig.cap=CAPTION------------------------------------------------------------------
plotmap(
  uneven,
  panel = panel.levelplot.points,
  cex = 0.75,
  col.symbol = NA
)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "Unevenly spaced measurement grid: example IV.  "

## ----uneven-IV, fig.cap=CAPTION-------------------------------------------------------------------
rx <- raster_make(uneven$x, startx = -11.55, d = 1, tol = 0.3)
uneven$x <- rx$x

ry <- raster_make(uneven$y, startx = -4.77, d = 1, tol = 0.3)
uneven$y <- ry$x

plotmap(uneven)

## ----rgl-plot, eval=FALSE, fig.cap=CAPTION--------------------------------------------------------
#  library(rgl)
#  
#  laser <- laser [, , 404.8 ~ 405.6] / 10000
#  laser$t <- laser$t / 3600
#  cols <- rep(palette_matlab(nrow(laser)), nwl(laser))
#  surface3d(
#    y = wl(laser), x = laser$t,
#    z = laser$spc, col = cols
#  )
#  aspect3d(c(1, 1, 0.25))
#  axes3d(c("x+-", "y--", "z--"))
#  axes3d("y--", nticks = 25, labels = FALSE)
#  mtext3d("t / h", "x+-", line = 2.5)
#  mtext3d("lambda / nm", "y--", line = 2.5)
#  mtext3d("I / a.u.", edge = "z--", line = 2.5)

## ----include=FALSE--------------------------------------------------------------------------------
CAPTION = "A snapshot of an **rgl** plot.  "

## ----rgl-plot-png, echo=FALSE, fig.cap=CAPTION, out.width="100%"----------------------------------
knitr::include_graphics("plotting--fig-3D-01.png")

## ----rgl-do, echo=show_reviewers_notes, results='hide', eval=FALSE--------------------------------
#  # FIXME: is this code block still needed?
#  
#  if (require(rgl)) {
#    open3d(windowRect = c(20, 20, 600, 350)) # this is needed only for automatically
#    # producing the snapshot
#    # <<rgl-plot>>
#    par3d(
#      userMatrix = matrix(c(
#        -0.52, 0.4, -0.75, 0,
#        -0.85, -0.28, 0.44, 0,
#        -0.04, 0.87, 0.49, 0,
#        -0.75, 0.75, 0, 1
#      ), ncol = 4L),
#      scale = c(2.75, 5, 0.175),
#      windowRect = c(20L, 50L, 520L, 330L),
#      zoom = 0.75
#    )
#    rgl.snapshot("fig-3D.png", fmt = "png", top = TRUE)
#    rgl.quit()
#  
#  } else {
#    png("fig-3D.png")
#    ploterrormsg("", "rgl")
#    dev.off()
#  }

## ----eval=FALSE-----------------------------------------------------------------------------------
#  identify_spc(plot_spc(paracetamol, wl.range = c(600 ~ 1800, 2800 ~ 3200), xoffset = 800))

## ----eval=FALSE-----------------------------------------------------------------------------------
#  map.identify(faux_cell[ , , 1200])

## ----eval=FALSE-----------------------------------------------------------------------------------
#  map.sel.poly(faux_cell[ , , 1200])

## ----eval=FALSE-----------------------------------------------------------------------------------
#  plot(laser, "mat")
#  trellis.focus()
#  grid.locator()

## ----session-info-plotting, paged.print=FALSE-----------------------------------------------------
sessioninfo::session_info("hyperSpec")

